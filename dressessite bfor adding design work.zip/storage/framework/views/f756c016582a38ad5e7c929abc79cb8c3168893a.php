

<?php $__env->startSection('content'); ?>

  <div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo e(route('site_map')); ?>">Site Map</a></li>
      </ul>
      <!-- Breadcrumb End-->

      <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
        <h1 class="title">Site Map</h1>

            <p class="brand-index"><strong>Category Index:</strong>
              <a href="#Women">Women</a>

              <a href="#Men">Men</a>

              <a href="#Baby">Baby</a>

              <a href="#Girl">Girl</a>

              <a href="#Boy">Boy</a>
            </p>
            <div class="manufacturer-info">
            
                <h4 id="Women" class="manufacturer-title">
                  <a href="/stores/women/all">Women</a>
                </h4>
                <div class="row">
                  <?php $__currentLoopData = $categories_counts['women']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="col-sm-2 col-xs-6 manufacturer">
                    <a href="/stores/<?php echo e($item['count_id']); ?>">
                      <?php echo e(($item['count_name'])); ?>

                       <?php if($item['total_count']>0): ?>
                        (<?php echo e($item['total_count']); ?>)
                      <?php endif; ?>
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                 <h4 id="Men" class="manufacturer-title">
                  <a href="/stores/men/all">Men</a>
                </h4>
                <div class="row">
                  <?php $__currentLoopData = $categories_counts['men']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="col-sm-2 col-xs-6 manufacturer">
                    <a href="/stores/<?php echo e($item['count_id']); ?>">
                      <?php echo e(($item['count_name'])); ?>

                       <?php if($item['total_count']>0): ?>
                        (<?php echo e($item['total_count']); ?>)
                      <?php endif; ?>
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <h4 id="Baby" class="manufacturer-title">
                  <a href="/stores/baby/all">Baby</a>
                </h4>
                <div class="row">
                  <?php $__currentLoopData = $categories_counts['baby']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="col-sm-2 col-xs-6 manufacturer">
                    <a href="/stores/<?php echo e($item['count_id']); ?>">
                      <?php echo e(($item['count_name'])); ?>

                       <?php if($item['total_count']>0): ?>
                        (<?php echo e($item['total_count']); ?>)
                      <?php endif; ?>
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

               
                <h4 id="Girl" class="manufacturer-title">
                  <a href="/stores/girl/all">Girl</a>
                </h4>
                <div class="row">
                  <?php $__currentLoopData = $categories_counts['girl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="col-sm-2 col-xs-6 manufacturer">
                    <a href="/stores/<?php echo e($item['count_id']); ?>">
                      <?php echo e(($item['count_name'])); ?> 
                      <?php if($item['total_count']>0): ?>
                        (<?php echo e($item['total_count']); ?>)
                      <?php endif; ?>
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <h4 id="Boy" class="manufacturer-title">
                  <a href="/stores/boy/all">Boy</a>
                </h4>
                <div class="row">
                  <?php $__currentLoopData = $categories_counts['boy']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="col-sm-2 col-xs-6 manufacturer">
                    <a href="/stores/<?php echo e($item['count_id']); ?>">
                      <?php echo e(($item['count_name'])); ?>

                       <?php if($item['total_count']>0): ?>
                        (<?php echo e($item['total_count']); ?>)
                      <?php endif; ?>
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/site_map.blade.php ENDPATH**/ ?>