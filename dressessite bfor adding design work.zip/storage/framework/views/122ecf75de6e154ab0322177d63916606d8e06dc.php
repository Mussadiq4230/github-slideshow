

<?php $__env->startSection('content'); ?>

<style type="text/css">
   #bussiness_search .dropdown-menu>.active>a, .dropdown-menu>.active>a:hover, .dropdown-menu>.active>a:focus {
    color:inherit !important;
    background: #d0d0d1 !important;
  }

  .page-item.active .page-link {
    background: #000 !important;
    border-color: #000 !important;
  }
</style>
	<div id="container">

    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo e(route('businesses')); ?>">Businesses</a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!--Middle Part Start-->

        <div id="content" class="col-sm-9">
        <h1 class="title">Find Businesses Near You</h1>

        <form id="form_filter_business" action ="<?php echo e(route('businesses')); ?>" method="get">
          
          <div class="product-filter" style="padding: 14px 14px;">
            <div class="row" id="bussiness_search">
              
              <div class="col-md-4 col-sm-5">
                <input type="text" value="<?php echo e(isset($request_data->search_business) ? $request_data->search_business : ''); ?>" id="search_business" name="search_business"  placeholder="What? i.e. Formal Dresses" class="form-control" style="height: 34px;" />
                
              </div>
              
              <div class="col-md-4 col-sm-5">
                  <input type="text" id="search_address" name="search_address" value="<?php echo isset($request_data->search_address ) ? $request_data->search_address : ''; ?>" placeholder="Where? i.e. NY" class="form-control" style="height: 34px;" />
                  <b style="cursor: pointer" onclick="checkLocation()">
                    <i class="fas fa-map-marker"></i> 
                    Use my current location?
                  </b>
               </div>
              
               <input type="hidden" name="latitude" value="<?php echo e(isset($request_data->latitude ) ? $request_data->latitude : ''); ?>" id="latitude"/>
               <input type="hidden" name="longitude" value="<?php echo e(isset($request_data->longitude ) ? $request_data->longitude : ''); ?>" id="longitude"/>
               <?php echo csrf_field(); ?>

              <div class="col-sm-1 text-left">
                <button type="submit" name="submit" class="btn btn-primary"  style="height: 34px;font-size: 15px;">
                  <i class="fa fa-search"></i>
                </button>
              </div>

             
               <div class="col-sm-3 text-right " style="font-size: 14px;font-weight: bold">
                <a href="<?php echo e(route('businesses')); ?>" >
                <i class="fa fa-filter"></i>   Clear All
                </a>
              </div>

            </div>

          </div>

       
         <div class="row products-category" >

          <?php if($businesses && $businesses->total() >0 ): ?>

            <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             
                <div class="product-layout product-list col-xs-12" >
                  <div class="product-thumb">
               <!--      <div class="image"><a href="https://www.nastygal.com//get-some-sunflower-floral-mini-dress/AGG44937.html" target="blank"><img src="//media.nastygal.com/i/nastygal/agg44937_black_xl?$product_image_category_page_horizontal_filters_desktop$" alt=" Strategies for Acquiring Your Own Laptop " title=" Strategies for Acquiring Your Own Laptop " class="img-responsive"></a></div> -->
                    <div>
                      <div class="caption">
                        <h4><a href="<?php echo e(route('business_details',['business_id'=> $business->service_store_slug])); ?>" target="blank"> <?php echo e($business->name); ?></a></h4>

                        <p class="description">
                          <?php echo e($business->street_address); ?>,<br/> <?php echo e($business->city); ?> <?php echo e($business->zip_code); ?>, <?php echo e($business->state); ?>, <?php echo e($business->country); ?>

                        </p>

                        <p class="description"><?php echo e($business->name); ?> is well known for specializing in formal and casual wear. Casa Orquidea proudly carries a wide variety of..<a href="<?php echo e(route('business_details',['business_id'=> $business->service_store_slug])); ?>"><b>Read more</b></a> </p>
                        <?php if($business->categories !=""): ?> 
                              <p> <b><?php echo e($business->categories); ?></b></p>
                            <?php endif; ?>
                            <?php if($business->email !=""): ?> 
                              <p><b>Email</b>: <?php echo e($business->email); ?></p> 
                            <?php endif; ?>
                            <?php if($business->phone !=""): ?> 
                              <p> <b>Phone:</b> <?php echo e($business->phone); ?> </p>
                            <?php endif; ?>
                            <?php if($business->website !=""): ?> 
                              <p> <b>Website:</b><a href="<?php echo e($business->website); ?>"><?php echo e($business->website); ?></a></p>
                            <?php endif; ?>
                            <?php if($business->years_in_business !=""): ?> 
                              <p> <b>Years in Business:</b>
                              <?php if($business->years_in_business == 0): ?>
                                about 1 year
                              <?php else: ?>
                                <?php echo e($business->years_in_business); ?> years
                              <?php endif; ?>
                              </p>
                            <?php endif; ?>
                          
                        
                      </div>
                      <div class="button-group">
                        <button class="btn-primary" type="button" href="<?php echo e(route('business_details',['business_id'=> $business->service_store_slug])); ?>"><span>View Details</span></button>
                       <!--  <div class="add-to-links">
                          <button type="button" data-toggle="tooltip" title="" onclick="" data-original-title="Add to wishlist"><i class="fa fa-heart"></i></button>
                        </div> -->
                      </div>
                    </div>
                  </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
           <div class="row products-category" >
               <div class="product-layout product-list col-xs-12" >
             <h4>No Matching businesses found. <a style="font-weight:bold;" href="<?php echo e(route('businesses')); ?>">Clear Selection</a></h4>
           </div>
           </div>
          <?php endif; ?>

            </div> 
            <div class="row">
              <div class="col-sm-12 text-left">
                  <p>
                   <?php echo e($businesses && $businesses->total() >0 ? $businesses->withQueryString()->links('pagination::bootstrap-4') : ""); ?>

                  </p>
              
                  <p>
                    <?php if($businesses && $businesses->total() >0): ?>
                      Showing <?php echo e(count($businesses->items())); ?> out of <?php echo e($businesses->total()); ?> items 
                    <?php endif; ?></p>
     
              </div>
            </div>
        </form> 
        </div>
          <div id="content" class="col-sm-3" >
            <img src="<?php echo e(asset('image/add1.jpg')); ?>" class="col-md-12" style="margin-top: 20%">
            <br>
            <img src="<?php echo e(asset('image/add2.jpg')); ?>" class="col-md-12" style="margin-top: 20%"></div>
         </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js" ></script>

<script type="text/javascript">

  function  checkLocation(){
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else {
      alert("Geolocation is not supported by this browser.");
    }

  }

  function showPosition(position){

    if(position.coords){
      $("#latitude").val(position.coords.latitude);
      $("#longitude").val(position.coords.longitude);
      $("#search_address").val('Using Current Location');
      $("#form_filter_business").submit();
    }
  }

   $('#search_business').change(function() {

      $('#form_filter_business').submit();
   });

  var route = "<?php echo e(url('ac_business_search')); ?>";

  $('#search_business').typeahead({
    name:'search_business',

      source: function (query, process) {
         if(query !=""){
          return $.get(route, {
              query: query
          }, function (data) {
              return process(data);
          });
        }
      }
  });

  var route_address = "<?php echo e(url('ac_business_search')); ?>";

   $('#search_address').typeahead({
    name:'search_address',
      source: function (query2, process) {
        if(query2 !=""){
          return $.get(route_address, {
              query_address: query2
          }, function (data) {
              return process(data);
          });
        }
      }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/businesses/businesses.blade.php ENDPATH**/ ?>