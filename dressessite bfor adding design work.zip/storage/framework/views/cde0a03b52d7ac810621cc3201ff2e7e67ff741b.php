

<?php $__env->startSection('content'); ?>

<div id="container">
  <div class="container">
    <!-- Breadcrumb Start-->
    <ul class="breadcrumb">
      <li><a href="/"><i class="fa fa-home"></i></a></li>
      <li><a href="/account">My Favourites</a></li>
    </ul>
    <!-- Breadcrumb End-->
    <div class="row">
      <!--Middle Part Start-->
      <div id="content" class="col-sm-12">
       
        <div class="row">
          <div class="col-sm-3">
           <?php echo $__env->make('users.my_account_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="col-sm-9">

          <?php $__currentLoopData = ['danger', 'success','warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has($status)): ?>
          <p class="alert alert-<?php echo e($status); ?> alert-dismissible" role="alert"><?php echo e(Session::get($status)); ?> <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button></p>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <h2 class="subtitle">
            Favourites List 
            <?php if($favourites->total()>0): ?>
              (<?php echo e($favourites->total()); ?>)
            <?php endif; ?>
          </h2>

          <div  class="row">
            <div class="col-md-12 ">
              <div class="table-responsive">

                <?php if($favourites): ?>
                <table class="table table-stripped" style="    border: 1px solid #dee2e6;!important; ">
                  <thead style="background: #283048;color:white;vertical-align: middle">
                    <tr>
                      <td class="text-center">Image</td>
                      <td class="text-left">Product Name</td>
                      <td class="text-center">Brand/Online Store</td>
                      <td class="text-center">Price</td>
                      <td class="text-center">Size</td>
                      <td class="text-center">Color</td>
                      <td class="text-right">Date Added</td>
                      <td></td>                      
                      <td></td>
                    </tr>
                  </thead>
                  <tbody>
                    
                    <?php $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favourite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="text-center">
                          <a href="#"  onclick="redirectProduct('<?php echo e($favourite->product->id); ?>','yes')">
                            <img class="img-thumbnail" title="<?php echo e($favourite->product->name); ?>" alt="<?php echo e($favourite->product->name); ?>" src="<?php echo e($favourite->product->image); ?>">
                          </a>
                        </td>
                        
                        <td class="text-left">
                          <a href="#" onclick="redirectProduct('<?php echo e($favourite->product->id); ?>','no')">
                            <?php echo e($favourite->product->name); ?>

                          </a>
                        </td>
                        
                        <td class="text-center"><?php echo e($favourite->product->store_name); ?></td>
                        
                        <td class="text-center">
                          <span class="price-old">
                            <?php echo e($favourite->product->currency); ?><?php echo e($favourite->product->price); ?>

                          </span> 
                          
                          <span itemprop="price"> <?php echo e($favourite->product->currency); ?><?php echo e($favourite->product->sale_price); ?>

                          </span>
                        </td>
                        
                        <td class="text-center"><?php echo e($favourite->product->size); ?></td>
                        
                        <td class="text-center"><?php echo e($favourite->product->color); ?></td>

                        <td class="text-right"><?php echo e(date('F d, Y h:i:sa',strtotime($favourite->created_at))); ?></td>
                        <td class="text-center">
                          <a class="btn btn-primary" title="" data-toggle="tooltip" href="#" onclick="redirectProduct('<?php echo e($favourite->product->id); ?>','no')" data-original-title="View">
                            <i class="fa fa-eye"></i>
                          </a>
                        </td>

                        <td class="text-center">
                          <a class="btn btn-danger" title="" data-toggle="tooltip" href="<?php echo e(route('delete_favourite',['id' => $favourite->id])); ?>" data-original-title="Remove favourite">
                            <i class="fa fa-remove"></i>
                          </a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                  </tbody>
                </table>
                
                

                <?php else: ?>
                  <b>
                    No favourites found.
                  </b>
                <?php endif; ?>
              </div>

              <?php if($favourites && $favourites->total() >0): ?>
                <br/>
                <div class="row">

                  <div class="col-sm-6 ">
                    <b>
                     
                      Showing 
                      <?php if($favourites->currentPage() == 1): ?>
                        1
                      <?php else: ?>
                        <?php echo e(($favourites->currentPage()-1) * $favourites->perPage()); ?>

                      <?php endif; ?>

                       to <?php echo e($favourites->currentPage() * $favourites->perPage()); ?> out of <?php echo e($favourites->total()); ?> items
                    </b> 
                  </div>

                  <div class="col-sm-6 text-right" >
                    <?php echo e($favourites && $favourites->total() >0 ? $favourites->withQueryString()->links('pagination::bootstrap-4') : ""); ?>

                  </div>
             
                  
                </div>
               <br/>
              <?php endif; ?>

            </div>

          </div>

          

        </div>
      </div>

    </div>    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/users/favourite_list.blade.php ENDPATH**/ ?>