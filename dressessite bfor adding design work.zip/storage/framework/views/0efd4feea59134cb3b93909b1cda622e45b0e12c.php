

<?php $__env->startSection('content'); ?>

<div id="container">
  <div class="container">
    <!-- Breadcrumb Start-->
    <ul class="breadcrumb">
      <li><a href="/"><i class="fa fa-home"></i></a></li>
      <li><a href="/account">Email Alerts</a></li>
    </ul>
    <!-- Breadcrumb End-->
    <div class="row">
      <!--Middle Part Start-->
      <div id="content" class="col-sm-12">
       
        <div class="row">
          <div class="col-sm-3">
           <?php echo $__env->make('users.my_account_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="col-sm-9">

          <?php $__currentLoopData = ['danger', 'success','warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Session::has($status)): ?>
            <p class="alert alert-<?php echo e($status); ?> alert-dismissible" role="alert"><?php echo e(Session::get($status)); ?> <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button></p>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <h2 class="subtitle">
            Email Alerts
            <?php if($email_alerts->total()>0): ?>
              (<?php echo e($email_alerts->total()); ?>)
            <?php endif; ?>
          </h2>

          <div  class="row">
            <div class="col-md-12 ">
              <div class="table-responsive">

                <?php if($email_alerts): ?>
                <table class="table table-stripped" style="    border: 1px solid #dee2e6;!important; ">
                  <thead style="background: #283048;color:white;vertical-align: middle">
                    <tr>
                      <td class="text-center">Alert Type</td>
                      <td class="text-left">Alert For</td>
                      <td class="text-center">Email Address</td>
                      <td class="text-center">Nature</td>
                      <td class="text-center">Status</td>
                      <td class="text-right">Date Added</td>           
                      <td>Edit</td>
                      <td>Remove</td>
                    </tr>
                  </thead>
                  <tbody>
                    
                    <?php $__currentLoopData = $email_alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert_email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>

                        <td class="text-left">
                            <?php echo e($alert_email->alert_type); ?>

                        </td>
                        
                        <td class="text-center">
                          <?php if($alert_email->alert_type == "Product"): ?>
                            
                            <?php echo e($alert_email->product ? $alert_email->product->name: ""); ?>

                          
                          <?php elseif($alert_email->alert_type == "Category"): ?>
                          
                            <?php if($alert_email->parent_category && $alert_email->parent_category->parent_category_name !=""): ?>
                              
                              <?php echo e($alert_email->parent_category->parent_category_name); ?>

                            
                            <?php endif; ?>

                            <?php if($alert_email->our_category && $alert_email->our_category->category_name !=""): ?>
                              
                              <?php echo e($alert_email->our_category->category_name); ?>

                            
                            <?php endif; ?>
                         
                          <?php elseif($alert_email->alert_type == "Store"): ?>

                            <?php echo e($alert_email->store->store_name); ?>

                          
                          <?php endif; ?>
                        </td>
                        
                        <td class="text-center"><?php echo e($alert_email->email_address); ?></td>
                        
                        <td class="text-center"><?php echo e($alert_email->alert_nature); ?></td>

                        <td >

                          <?php if($alert_email->alert_status == 'Active'): ?>
                            <span class="badge badge-success"> 
                              <?php echo e($alert_email->alert_status); ?>

                            </span>
                          <?php else: ?>
                             <span class="badge badge-danger"> 
                              <?php echo e($alert_email->alert_status); ?>

                            </span>
                          <?php endif; ?>
                         
                        </td>

                        <td class="text-right"><?php echo e(date('F d, Y h:i:sa',strtotime($alert_email->created_at))); ?></td>

                      

                        <td class="text-center">
                          <a class="btn btn-warning" title="" data-toggle="tooltip"  href="#edit_alert<?php echo e($alert_email->id); ?>" onclick="showAlertModal('<?php echo e($alert_email->id); ?>')" data-original-title="Edit">
                            <i class="fa fa-edit"></i>
                          </a>

                          <div class="modal fade" id="edit_alert<?php echo e($alert_email->id); ?>" role="document">
                            <div class="modal-dialog modal-md">
                              <!-- Modal content-->
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h2 class="modal-title">Edit Alert</h2>
                                </div>
                                 <form class="form-horizontal" action="<?php echo e(route('edit_email_alert')); ?>" method="post">
                                    
                                <div class="modal-body" >
                                 
                                    <div class="form-group required">
                                      <label class="col-sm-2 control-label">Status</label>
                                      <div class="col-sm-4">
                                       
                                         <label class="radio-inline">
                                            <input type="radio" value="Active" name="alert_status"  <?php if($alert_email->alert_status == 'Active'): ?> checked='true'  <?php endif; ?> >
                                            Active
                                        </label>
                                          <label class="radio-inline">
                                            <input type="radio" value="Inactive" name="alert_status" <?php if($alert_email->alert_status == 'Inactive'): ?> checked='true'  <?php endif; ?> >
                                            Inactive
                                        </label>
                                      
                                      </div>
                                    </div>


                                      <div class="form-group required">
                                      <label class="col-sm-2 control-label">Nature</label>
                                      <div class="col-sm-10">
                                       
                                        <select class="form-control col-md-6" name="alert_nature">
                                          <option value="Daily"
                                          <?php if($alert_email->alert_nature == "Daily"): ?> selected="selected" <?php endif; ?>
                                          >Daily</option>
                                          <option value="Weekly"
                                           <?php if($alert_email->alert_nature == "Weekly"): ?> selected="selected" <?php endif; ?>
                                          >Weekly</option>
                                        </select>
                                      
                                      </div>
                                    </div>
                                    <input type="hidden" name="update_id" value='<?php echo e($alert_email->id); ?>' />
                                   
                                       <?php echo csrf_field(); ?>

                                </div>
                                <div class="modal-footer">
                                  <input type="button" onclick="hideAlertEditModal('<?php echo e($alert_email->id); ?>')" class="btn btn-default" value="Close">
                                   <input class="btn btn-primary" type="submit" name="submit" value="Submit"/>
                                </div>
                                  </form> 

                              </div>
                            </div>
                          </div>
                      
                        </td>

                        <td class="text-center">
                          <a class="btn btn-danger" title="" data-toggle="tooltip" href="<?php echo e(route('delete_alert_email',['id' => $alert_email->id])); ?>" data-original-title="Remove alert email">
                            <i class="fa fa-remove"></i>
                          </a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                  </tbody>
                </table>
                
                

                <?php else: ?>
                  <b>
                    No email alerts found.
                  </b>
                <?php endif; ?>
              </div>

              <?php if($email_alerts && $email_alerts->total() >0): ?>
                <br/>
                <div class="row">

                  <div class="col-sm-6 ">
                    <b>
                     
                      Showing 
                      <?php if($email_alerts->currentPage() == 1): ?>
                        1
                      <?php else: ?>
                        <?php echo e(($email_alerts->currentPage()-1) * $email_alerts->perPage()); ?>

                      <?php endif; ?>

                       to <?php echo e($email_alerts->currentPage() * $email_alerts->perPage()); ?> out of <?php echo e($email_alerts->total()); ?> items
                    </b> 
                  </div>

                  <div class="col-sm-6 text-right">
                    <?php echo e($email_alerts && $email_alerts->total() >0 ? $email_alerts->withQueryString()->links('pagination::bootstrap-4') : ""); ?>

                  </div>
             
                  
                </div>
               <br/>
              <?php endif; ?>

            </div>

          </div>

          

        </div>
      </div>

    </div>    
  </div>
</div>
<script type="text/javascript">
  function hideAlertEditModal(id){
    $("#edit_alert"+id).modal('hide');
  }
  function  showAlertModal(id){
    $("#edit_alert"+id).modal('show');
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/users/email_alerts.blade.php ENDPATH**/ ?>