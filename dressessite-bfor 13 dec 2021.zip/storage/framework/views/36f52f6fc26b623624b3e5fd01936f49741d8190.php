<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="format-detection" content="telephone=no" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link href="image/favicon.png" rel="icon" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Trouser Ads - Ads Network</title>
  <meta name="description" content="Find all sorts of dresses from famous brands and stores from all over the internet.">
  <!-- CSS Part Start-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/bootstrap/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/stylesheet.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.carousel.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.transitions.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/stylesheet-skin3.css')); ?>" />
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/customstyle.css')); ?>" />
  <link href='//fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
  <div class="wrapper-wide">
    <div id="header">
      <!-- Top Bar Start-->
      <nav id="top" class="htop">
        <div class="container">
          <div class="row"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
            <div class="pull-left flip left-top">
            <!--   <div class="links">
                <ul>
                  <li class="mobile"><i class="fa fa-phone"></i>+91 9898777656</li>
                  <li class="email"><a href="mailto:info@marketshop.com"><i class="fa fa-envelope"></i>info@marketshop.com</a></li>
        
                  <li><a href="#">Wish List (0)</a></li>
                  <li><a href="checkout.html">Checkout</a></li>
                </ul>
              </div> -->
           
            </div>
            <div id="top-links" class="nav pull-right flip">
              <ul>
                <li><a href="#">Login</a></li>
                <li><a href="#">Register</a></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
      <!-- Top Bar End-->
      <!-- Header Start-->
      <header class="header-row">
        <div class="container">
          <div class="table-container">
            <!-- Logo Start -->
            <div class="col-table-cell col-lg-6 col-md-6 col-sm-12 col-xs-12 inner">
              <div id="logo"><a href="index.html"><img class="img-responsive" src="image/logo.png" title="MarketShop" alt="MarketShop" /></a></div>
            </div>
            <!-- Logo End -->
            <!-- Search Start-->
            <div class="col-table-cell col-lg-6 col-md-6 col-md-push-0 col-sm-6 col-sm-push-6 col-xs-12">
              <div id="search" class="input-group" style="width: 75% !important">
                <input id="filter_name" type="text" name="search" value="" placeholder="Search" class="form-control input-lg" />
                <button type="button" class="button-search"><i class="fa fa-search"></i></button>

              </div>
               <button type="button" class="btn " style="height: 36px;width:25% !important;background:#01a161;color:white" data-loading-text="Loading..." data-toggle="modal" data-target="#myModal">Advance Search</button>
         

              <!-- Modal Starts Adv Search -->
              <div class="modal fade" id="myModal" role="document">
                <div class="modal-dialog modal-lg">
                
                  <!-- Modal content-->
                  <div class="modal-content">
                   
                    <div class="modal-body">
                      <h4>Advance Search</h4>
                      <hr/>
                      <div class="row">
                  
                        <div class="col-lg-3">
                          <div class="form-group">
                            <label class="control-label" for="parent_cateogry">Select Main Category</label>
                            <select name="parent_category" id="parent_category" class="form-control" required="">
                              <option value="all">All</option>
                              <?php $__currentLoopData = $pc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p_category->id); ?>"><?php echo e($p_category->parent_category_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                          </div>
                        </div>
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label class="control-label" for="category_name">Select Category</label>
                            <select name="category_name" id="category_name" class="form-control" required="">
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              <option value="all">All</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group ">
                            <label class="control-label" for="store_id">Select Store</label>
                            <select name="store_id" id="store_id" class="form-control" required="" >
                              <option value="all">All Stores</option>
                              <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($store->id); ?>"><?php echo e($store->store_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-12">
                               <label class="control-label" for="">By Price</label>
                        </div>

                        <div class="col-lg-6">
                       
                            <div  class="form-inline">
                             
                         
                                <div class="form-group   input-group" >
                              <label class="control-label input-group-addon" for="min_price">$</label>
                              <input type="number" class="form-control" min="0" name="min_price" placeholder="Min" >
                              </div>
                              <span>-</span>

                       
                                <div class="form-group  input-group" >
                              <label class="control-label input-group-addon" for="max_price">$</label>
                              <input type="number" class="form-control" min="0" name="max_price" placeholder="Max" >
                        
                          </div>
                          
                            </div>
                                <br/>  
                        </div>
                      <div class="col-lg-3" >
                          <div class="container" style="padding-left: 2rem">
                            <label class="radio">
                              <input type="radio" class="radio" name="price_range" value="0-100"> <span>$0 - $100</span>
                             </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="100-200"> <span>$100 - $200</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="200-500" /> <span>$200 - $500</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="500-1000"/> <span>$500 - $1000</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="1000+"> <span>$1000+</span>
                              </label>
                          </div>
                         </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label class="control-label" for="colors">By Color</label>
                              <br/>
                              <div id='colors'>
                                <div class="row">
                                  <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4" style="min-width: max-content">
                                      <input type="checkbox" name="selected_colors[]" value=<?php echo e($color->id); ?> /> <span style="margin-left:2px">  <?php echo e($color->color_name); ?> </span>
                                    </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              </div>
                          </div>
                        </div>

                        <div class="col-lg-12">
                          <div class="form-group">
                            <label class="control-label" for="store_id">By Size</label>
                              <br/>
                              <div id='sizes'>
                                <div class="row">
                                  <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                      <input type="checkbox" name="selected_sizes[]" value=<?php echo e($size->id); ?> /> <span style="margin-left:2px">  <?php echo e($size->size_name); ?> </span>
                                    </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              </div>
                          </div>
                        </div>

                      </div>
                 
                    </div>
                        <div class="modal-footer">
                     <button type="submit" class="btn btn-primary">Search</button>
                  </div>
                  </div>
                 
                </div>
              </div>
  
              <!-- End Modal -->
            </div>
            <!-- Mini Cart End-->
          </div>
        </div>
      </header>
      <!-- Header End-->
      <!-- Main Menu Start-->
      <nav id="menu" class="navbar">
        <div class="container">
          <div class="navbar-header"> <span class="visible-xs visible-sm"> Menu <b></b></span></div>
          <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav">
              <li><a class="home_link" title="Home" href="/home"><span>Home</span></a></li>
       
                 <?php $__currentLoopData = $pc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                
                <?php if($pc_category->parent_category_name == "Kids"): ?>
                  <li class="dropdown wrap_custom_block hidden-sm hidden-xs"><a href="/category_products/<?php echo e($pc_category->parent_category_name); ?>"><?php echo e($pc_category->parent_category_name); ?></a>
                    <div class="dropdown-menu custom_block">
                      <ul>
                        <li>
                          <table>
                            <tbody>
                              <tr>
                                <td><img alt="" src="image/banner/cms-block.jpg"></td>
                                <td><img alt="" src="image/banner/responsive.jpg"></td>
                                <td><img alt="" src="image/banner/cms-block.jpg"></td>
                              </tr>
                             
                             
                               <tr>
                                 <?php $__currentLoopData = $pc_category->sub_parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subparent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($subparent->parent_category_name !="Toodler"): ?>
                                   
                                    <td>
                                       <?php $__currentLoopData = $subparent->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="/category_products/<?php echo e($subparent->parent_category_name); ?>/<?php echo e($our_cat->category_name); ?>" class="btn btn-default"><?php echo e($our_cat->category_name); ?></a>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                              
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                              </tr>
                            
                            </tbody>
                          </table>
                        </li>
                      </ul>
                    </div>
                  </li>
                <?php else: ?>
                <li class="dropdown"><a href="/category_products/<?php echo e($pc_category->parent_category_name); ?>"><?php echo e($pc_category->parent_category_name); ?>

                </a>
                  <div class="dropdown-menu" >
                      
                      <?php if($pc_category->our_categories && !empty($pc_category->our_categories)): ?>
                      
                        <?php 
                       
                        $count_index = 0;
                      
                         $max_count = count($pc_category->our_categories)/3;
                         $cats1 = array_slice($pc_category->our_categories,$count_index, $max_count);
                         
                         $count_index = $max_count;
                         $max_count = $max_count;
                          $cats2 = array_slice($pc_category->our_categories,$count_index, $max_count);

                           $count_index = count($cats1)+count($cats2);
                         $max_count = count($pc_category->our_categories);
                          $cats3 = array_slice($pc_category->our_categories,$count_index, $max_count);
                       
                         ?>
                           
                         <ul>
                         <?php $__currentLoopData = $cats1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                          
                          <li><a href="/category_products/<?php echo e($pc_category->parent_category_name); ?>/<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                         <ul>
                         <?php $__currentLoopData = $cats2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                          <li><a href="/category_products/<?php echo e($pc_category->parent_category_name); ?>/<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                         <ul>
                         <?php $__currentLoopData = $cats3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                          <li><a href="/category_products/<?php echo e($pc_category->parent_category_name); ?>/<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     
                    <?php endif; ?>
                  </div>
                </li>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              <li class="contact-link">
                <a href="" >Today Sales</a>
              </li>
              <li class="contact-link">
                <a href="" >New Arrivals</a>
              </li>
              <li class="menu_brands dropdown"><a href="<?php echo e(route('online_brands')); ?>">Brands</a>
                <div class="dropdown-menu">
                      
                    <?php 
                    $brands_count = 0;
                    ?>
                    <div class="row" style="margin-left: 2rem">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    $brands_count++;
                    if($brands_count>10){
                      break;
                    }
                    ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6"><a href="#"><img src="logos/<?php echo e($brand->store_logo); ?>" class="logo" width="50" height="40" title="<?php echo e($brand->store_name); ?>" alt="<?php echo e($brand->store_name); ?>" /></a><a href="#"><?php echo e($brand->store_name); ?></a></div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                   <a style="margin-left: 2rem" href="<?php echo e(route('online_brands')); ?>" class="">More Brands</button>
                       <br/>
               
                </div>
              </li>
              <li class="menu_brands dropdown"><a href="<?php echo e(route('online_stores')); ?>">Online Stores</a>
                <div class="dropdown-menu">
                      
                    <?php 
                    $store_count = 0;
                    ?>
                    <div class="row" style="margin-left: 2rem">
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    $store_count++;
                    if($store_count>10){
                      break;
                    }
                    ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6"><a href="#"><img src="logos/<?php echo e($store->store_logo); ?>" class="logo" width="50" height="40" title="<?php echo e($store->store_name); ?>" alt="<?php echo e($store->store_name); ?>" /></a><a href="#"><?php echo e($store->store_name); ?></a></div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                   <a style="margin-left: 2rem" href="<?php echo e(route('online_stores')); ?>" class="">More Online Stores</button>
                       <br/>
               
                </div>
              </li>

              <li class="contact-link">
                <a href="" >Businesses</a>
              </li>
            
              <li class="custom-link-right dropdown"><a href="#" target="_blank">Special Offers</a>
               
              <div class="dropdown-menu">
                <ul>
                  <?php $__currentLoopData = $offer_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <a href="<?php echo e($offer_type); ?>"><?php echo e($offer_type); ?></a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- Main Menu End-->
    </div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="container">
      <div class="custom-feature-box row">
        <div class="col-sm-4 col-xs-12">
          <div class="feature-box fbox_1">
            <div class="title">Free Shipping</div>
            <p>Free shipping on order over $1000</p>
          </div>
        </div>
        <div class="col-sm-4 col-xs-12">
          <div class="feature-box fbox_3">
            <div class="title">Gift Cards</div>
            <p>Give the special perfect gift</p>
          </div>
        </div>
        <div class="col-sm-4 col-xs-12">
          <div class="feature-box fbox_4">
            <div class="title">Reward Points</div>
            <p>Earn and spend with ease</p>
          </div>
        </div>
      </div>
    </div>
    <!-- Feature Box End-->
    <!--Footer Start-->
    <footer id="footer">
      <div class="fpart-first">
        <div class="container">
          <div class="row">
            <div class="contact col-lg-3 col-md-3 col-sm-12 col-xs-12">
              <h5>Contact Details</h5>
              <ul>
                <li class="address"><i class="fa fa-map-marker"></i>Central Square, 22 Hoi Wing Road, New Delhi, India</li>
                <li class="mobile"><i class="fa fa-phone"></i>+91 9898777656</li>
                <li class="email"><i class="fa fa-envelope"></i>Send email via our <a href="contact-us.html">Contact Us</a>
                </ul>
              </div>
              <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                <h5>Information</h5>
                <ul>
                  <li><a href="about-us.html">About Us</a></li>
                  <li><a href="about-us.html">Delivery Information</a></li>
                  <li><a href="about-us.html">Privacy Policy</a></li>
                  <li><a href="about-us.html">Terms &amp; Conditions</a></li>
                </ul>
              </div>
              <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                <h5>Customer Service</h5>
                <ul>
                  <li><a href="contact-us.html">Contact Us</a></li>
                  <li><a href="returns.html">Returns</a></li>
                  <li><a href="sitemap.html">Site Map</a></li>
                </ul>
              </div>
              <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                <h5>Extras</h5>
                <ul>
                  <li><a href="manufacturer.html">Brands</a></li>
                  <li><a href="gift-voucher.html">Gift Vouchers</a></li>
                  <li><a href="#">Affiliates</a></li>
                  <li><a href="#">Specials</a></li>
                </ul>
              </div>
              <div class="column col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <h5>Newsletter</h5>
                <div class="form-group">
                  <label class="control-label" for="subscribe">Sign up to receive latest news and updates.</label>
                  <input id="signup" type="email" required="" placeholder="Email address" name="email" class="form-control">
                </div>
                <input type="submit" value="Subscribe" class="btn btn-primary">
              </div>
            </div>
          </div>
        </div>
        <div class="fpart-second">
          <div class="container">
            <div id="powered" class="clearfix">
              <div class="powered_text pull-left flip">
                <p>Marketshop Ecommerce Template © 2016 | Template By <a href="http://harnishdesign.net" target="_blank">Harnish Design</a></p>
              </div>
              <div class="social pull-right flip"> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/socialicons/facebook.png" alt="Facebook" title="Facebook"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/socialicons/twitter.png" alt="Twitter" title="Twitter"> </a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/socialicons/google_plus.png" alt="Google+" title="Google+"> </a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/socialicons/pinterest.png" alt="Pinterest" title="Pinterest"> </a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/socialicons/rss.png" alt="RSS" title="RSS"> </a> </div>
            </div>
            <div class="bottom-row">
              <div class="custom-text text-center"> <img alt="" src="image/logo-small.png">
                <p>This is a CMS block. You can insert any content (HTML, Text, Images) Here. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
              </div>
              <div class="payments_types"> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_paypal.png" alt="paypal" title="PayPal"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_american.png" alt="american-express" title="American Express"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_2checkout.png" alt="2checkout" title="2checkout"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_maestro.png" alt="maestro" title="Maestro"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_discover.png" alt="discover" title="Discover"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="image/payment/payment_mastercard.png" alt="mastercard" title="MasterCard"></a> </div>
            </div>
          </div>
        </div>
        <div id="back-top"><a data-toggle="tooltip" title="Back to Top" href="javascript:void(0)" class="backtotop"><i class="fa fa-chevron-up"></i></a></div>
      </footer>
      <!--Footer End-->

    </div>
    <!-- JS Part Start-->
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-2.1.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.easing-1.3.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.dcjqaccordion.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <!-- JS Part End-->
  </body>
  </html>

<script type="text/javascript">





    $("#parent_category").change(function(event){
      event.preventDefault();

      let parent_category = $("#parent_category").val();
  
      let _token   = $('meta[name="csrf-token"]').attr('content');

      $.ajax({
        url: "<?php echo e(route('get_our_categories')); ?>",
        type:"POST",
        data:{
          parent_category:parent_category,
         
          _token: _token
        },
        success:function(response){
          
          if(response && response !="") {
            $("#category_name").html(response);
          }
        },
       });
  }
  );

    $("#store_id").change(function(event){

      event.preventDefault();
      let store_id = $("#store_id").val();
      let _token = $("meta[name='csrf-token']").attr('content');

      $.ajax({
        url:"<?php echo e(route('get_colors')); ?>",
        type:"post",
        data:{
          store_id : store_id,
          _token : _token
        },
        success:function(response){
          if(response && response !="NOCOLOR"){
            $("#colors").html(response);
          }else if(response && response =="NOCOLOR"){
            $("#colors").html("Colors not available");
          }
        }

      });

      $.ajax({
        url:"<?php echo e(route('get_sizes')); ?>",
        type:"post",
        data:{
          store_id : store_id,
          _token : _token
        },
        success:function(response){
          if(response && response !="NOSIZE"){
            $("#sizes").html(response);
          }else if(response && response =="NOSIZE"){
            $("#sizes").html("Sizes not available");
          }
        }
        
      });
    });


</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trouserssite\resources\views/layouts/app.blade.php ENDPATH**/ ?>