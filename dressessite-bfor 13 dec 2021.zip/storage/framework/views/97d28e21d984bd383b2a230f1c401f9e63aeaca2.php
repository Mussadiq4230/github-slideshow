<span onclick="hideModalById('modal_product_alert')" style="float: right;
	cursor: pointer;
	color: #000;" >
	<i style="font-size: 21px;" class="fas fa-times"></i>
</span>

<div class="row " style="padding:10px">

	<div class="col-sm-12">
		<center>
			<h3 style="font-weight: normal;">Receive email alerts when the price drops for</h3>
			<h3 style="margin-top:15px;font-weight: bold">
				
				<?php if($type == 1): ?>
					
					<?php echo e($product->name); ?>


				<?php elseif($type == 2): ?>

					<?php if($parent_category && isset($parent_category->parent_category_name)): ?>

						<?php echo e($parent_category->parent_category_name); ?>


					<?php endif; ?>

					<?php if($our_category && isset($our_category->category_name)): ?>
						 > <?php echo e($our_category->category_name); ?>

					<?php endif; ?>

				<?php elseif($type == 3): ?>

					<?php if($store): ?>
						<?php echo e($store->store_name); ?>

					<?php endif; ?>
				<?php endif; ?>
			</h3>
		</center>
		<br/>
		
		<?php if(isset($product) && $type == 1): ?>

			<div class="col-md-5">
				
				<img class="img-thumbnail" title="<?php echo e($product->name); ?>" alt="<?php echo e($product->name); ?>" src="<?php echo e($product->image); ?>">
				
			</div>
			<div class="col-md-7">
				<form method="post" id="save_alert_form" action="<?php echo e(route('save_alert')); ?>">
				
					<label>Send me alerts on email</label>

					<?php if(Session::get('user')): ?>	
						<div class="form-group">
							<input type="text" class="form-control" name="alert_email" value="<?php echo e(Session::get('user')->email); ?>" placeholder="Email">
						</div>
						<br/>
						<input type="hidden" name="user_id" value="<?php echo e(Session::get('user')->id); ?>" />
					<?php else: ?>
						<div class="form-group">
							<input type="text" class="form-control" name="alert_email" value="" placeholder="Email">
						</div>
						<br/>
						<p>
							<b>Note: </b> If you do not have an account. Setting this alert will create an account for you.
							You will get email with login details shortly.
						</p>

					<?php endif; ?>

					<input type="hidden" name="alert_type" value="Product"/>
					<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
					  <?php echo csrf_field(); ?>

					<button type="button" class="btn btn-primary" onclick="save_alert('#save_alert_form')"> Set Alert </button>
					<br/><br/>
						<p>
							You can access your   
							<a href="/email_alerts">
								<b>Email Alerts</b>
							</a> 
							here.
						</p>
				</form>
			</div>

		<?php elseif(isset($store) && $type == 3): ?>

			<div class="col-md-5">
			
				<img class="img-thumbnail" title="<?php echo e($store->store_name); ?>" alt="<?php echo e($store->store_name); ?>" src="/logos/<?=$store->store_logo?>">
		
			</div>
			<div class="col-md-7">
				<form method="post" id="save_alert_form" action="<?php echo e(route('save_alert')); ?>">
				
					<label>Send me alerts on email</label>

					<?php if(Session::get('user')): ?>	
						<div class="form-group">
							<input type="text" class="form-control" name="alert_email" value="<?php echo e(Session::get('user')->email); ?>" placeholder="Email">
						</div>
						<br/>
						<input type="hidden" name="user_id" value="<?php echo e(Session::get('user')->id); ?>" />
					<?php else: ?>
						<div class="form-group">
							<input type="text" class="form-control" name="alert_email" value="" placeholder="Email">
						</div>
						<br/>
						<p>
							<b>Note: </b> If you do not have an account. Setting this alert will create an account for you.
							You will get email with login details shortly.
						</p>

					<?php endif; ?>

					<input type="hidden" name="alert_type" value="Store"/>
					<input type="hidden" name="store_id" value="<?php echo e($store->id); ?>" />
					  <?php echo csrf_field(); ?>

					<button type="button" class="btn btn-primary" onclick="save_alert('#save_alert_form')"> Set Alert </button>
					<br/><br/>
						<p>
							You can access your   
							<a href="/email_alerts">
								<b>Email Alerts</b>
							</a> 
							here.
						</p>
				</form>
			</div>

		<?php elseif($type == 2 && isset($our_category)): ?>

			<div class="col-md-12">
			<form method="post" id="save_alert_form" action="<?php echo e(route('save_alert')); ?>">
			
				<label>Send me alerts on email</label>

				<?php if(Session::get('user')): ?>	
					
					<div class="form-group col-sm-6 email_alert">
						<input type="text" class="form-control" id="alert_email" name="alert_email" value="<?php echo e(Session::get('user')->email); ?>" placeholder="Email">
						
					</div>
					<div class="col-md-6">
						
					</div>
					<br/>
					<input type="hidden" name="user_id" value="<?php echo e(Session::get('user')->id); ?>" />
				
				<?php else: ?>
					
					<div class="form-group col-sm-6 email_alert" >
						<input type="text" class="form-control" id="alert_email" name="alert_email" value="" placeholder="Email" required="">
					
					</div>
					<div class="col-md-6">
					
					</div>

					<br/>
					<div class="col-md-12">
						<p>
							<b>Note: </b> If you do not have an account. Setting this alert will create an account for you.
							You will get email with login details shortly.
						</p>
					</div>

				<?php endif; ?>
				<p style="display: none" id="alert_email_message" class="text-danger">Email is required!</p>
				<input type="hidden" name="alert_type" value="Category"/>
				<input type="hidden" name="our_category_id" value="<?php echo e(isset($our_category->id) ? $our_category->id: ''); ?>" />
				<input type="hidden" name="parent_category_id" value="<?php echo e($parent_category->id); ?>" />
				  <?php echo csrf_field(); ?>

				<button type="button" class="btn btn-primary" onclick="save_alert('#save_alert_form')"> Set Alert </button>
				<br/><br/>
					<p>
						You can access your   
						<a href="/email_alerts">
							<b>Email Alerts</b>
						</a> 
						here.
					</p>
			</form>
		</div>

		<?php endif; ?>

	</div>

</div>


<?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/contents/email_alert_content.blade.php ENDPATH**/ ?>