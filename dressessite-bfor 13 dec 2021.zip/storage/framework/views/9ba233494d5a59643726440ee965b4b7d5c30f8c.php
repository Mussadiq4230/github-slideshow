<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>
  <?php if(isset($page_title)): ?> 
    <?php echo e($page_title); ?> 
  <?php else: ?>  
    Dress Ads | Ads Network 
  <?php endif; ?>
</title>
<meta name="description" content="Find all sorts of dresses from famous brands and stores from all over the internet.">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/bootstrap/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



<script type="text/javascript" src="<?php echo e(asset('js/jquery-2.1.1.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/stylesheet.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.carousel.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.transitions.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/stylesheet-skin4.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('revolution/css/settings.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('revolution/css/layers.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('revolution/css/navigation.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/swipebox/src/css/swipebox.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />
<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900' type='text/css'>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">

<style type="text/css">
  .navbar-nav {
    display: block !important;
}
  .border_bottom{
        border-bottom: 2px solid #ddd;
        margin-bottom: 20px;
  }
  #column-left > h5
  {
    font-weight: bold;
  }
  .more{
    color:#795548;
    cursor:pointer;
    text-align: center;
   
    padding: 10px;
    font-weight: bold;
  }
  .less{
    padding: 10px;
    color:#795548;
    cursor:pointer;
    text-align: center;
    font-weight: bold;
  }
  .attributes{
    background: #f7f7f7;
    
    margin-left: 3px;
    margin-right: 3px;
  }
  .pl0{
    padding-left: 0px;
  }
  .pr0{
    padding-right: 0px;
  }
  .pl1{
    padding-left: 1px;
  }
  .pr1{
    padding-right: 1px;
  }
  .pl2{
    padding-left: 2px;
  }
  .pr2{
    padding-right: 2px;
  }

 #share-div .fa , #share-div .fab 
 {
  padding: 10px;
    font-size: 25px;
    width: 49px;
    text-align: center;
    text-decoration: none;
    margin: 5px 2px;
}

#share-div .fa:hover ,#share-div .fab:hover 
{
    opacity: 0.7;
}

#share-div .fa-facebook 
{
  background: #3B5998;
  color: white;
}

#share-div .fa-twitter 
{
  background: #55ACEE;
  color: white;
}

#share-div .fa-mail 
{
  background: #dd4b39;
  color: white;
}

#share-div .fa-tumblr 
{
  background: #2c4762;
  color: white;
}
#share-div .fa-linkedin 
{
  background: #007bb5;
  color: white;
}

#share-div .fa-instagram 
{
  background: #125688;
  color: white;
}

#share-div .fa-pinterest 
{
  background: #cb2027;
  color: white;
}



/* ######################################new style added ################### */
/* #header .button-search
{
    background-color:#03B5C9;
}
#header #search input
{
  border-color:1px solid #03B5C9;
} */
</style>
</head>
<body>
<div class="wrapper-wide">
  <div id="header" class="style2">
    <!-- Top Bar Start-->
    <nav id="top" class="htop">
      <div class="row no-gutter mx-2 default-width mx-auto">
        <div class=" w-100 d-flex justify-content-between align-items-center"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify" style="color:#fff;"></i></span>

          <div class="pull-left flip left-top d-flex justify-content-center align-items-center">
            
            <div class="links" style="border: 0">
              <ul>

                <li class="mobile text-center  " style="text-transform: none;border:0;"> Amazing Dress Deals! Up to 75% Off All Dresses with code: DRESSESADS</li>
                
     
              </ul>
            </div>
          
          </div>

          <div id="top-links" class="nav pull-right flip">
            <ul>
              <?php if(Session::has('user')): ?>
                <li><a href="/account">My Account</a></li>

                <li><span style="margin-left: 10px;font-size:14px">(<?php echo e(Session::get('user')->first_name); ?> <?php echo e(Session::get('user')->last_name); ?>)</span> <a href="/logout" style="padding-left: 0px">Logout</a></li>
              <?php else: ?>
              <li><a href="/login">Login</a></li>
              <li><a href="/register">Register</a></li>

              <?php endif; ?>
            </ul>
          </div>

        </div>
      </div>
    </nav>
    <!-- Top Bar End-->
    <!-- Header Start-->
    <header class="header-row">
      <div class="container default-width mx-auto">
        <div class="table-container">
           <!-- Logo Start -->
          <div class="col-table-cell col-lg-4 col-md-6 col-sm-12 col-xs-12">
            <div id="logo" style="text-align: left!important"><a href="<?php echo e(route('home')); ?>"><img class="img-responsive" src="<?php echo e(asset('image/logo.png')); ?>" title="Dress Ads" alt="Dress Ads" /></a></div>
          </div>
          <!-- Logo End -->
          <!-- Mini Cart Start-->
          <div class="col-table-cell col-lg-4 col-md-3 col-sm-12 col-xs-12 inner">
            
          </div>
          <!-- Mini Cart End-->
          


          </div>

      </div>
    </header>
    <!-- Header End-->
    <!-- Main Menu Start-->
    <nav id="menu" class="navbar center ">
      <div class="navbar-header"> <span class="visible-xs visible-sm"> Menu <b></b></span></div>
      <div class="container default-width mx-auto">
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a class="home_link" title="Home" href="<?php echo e(route('home')); ?>">Home</a></li>

                <?php $__currentLoopData = $pc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($pc_category->parent_category_name == "Kids"): ?>
                      <li class="dropdown wrap_custom_block hidden-sm hidden-xs"><a href="#" ><?php echo e($pc_category->parent_category_name); ?></a>
                        <div class="dropdown-menu custom_block">
                          <ul>
                            <li>
                              <table>
                                <tbody>
                                  <tr>
                                  
                                    <td>
                                      <a href="<?php echo e(route('shop.categoryProdcuts','baby')); ?>">
                                        <!-- <img alt="" title="Baby" src="<?php echo e(asset('image/baby.jpg')); ?>"> -->
                                        <div class="menuImages1" style="width:200px;height:130px;">
                                        <!-- <img alt="" title="Baby" src="<?php echo e(asset('image/vector/baby1.jpg')); ?>" style=
                                        "width:100%; height:100%"> -->
                                        </div>
                                      </a>
                                    </td>
                                    <td>
                                      <a href="<?php echo e(route('shop.categoryProdcuts','girl')); ?>">
                                        <!-- <img alt="" title="Girl" src="<?php echo e(asset('image/girls.jpg')); ?>"> -->
                                        <div class="menuImages2" 
                                        style="
                                        width:200px;height:130px;
                                        ">
                                        <!-- <img alt="" title="Girl" src="<?php echo e(asset('image/vector/girl2.png')); ?>" style=
                                        "width:100%; height:100%"> -->
                                        </div>
                                      </a>
                                    </td>
                                    <td>
                                      <a href="<?php echo e(route('shop.categoryProdcuts','boy')); ?>">
                                        <!-- <img alt="" title="Boy" src="<?php echo e(asset('image/boys.jpg')); ?>"> -->
                                        <div class="menuImages3" style="width:200px;height:130px;">
                                        <!-- <img alt="" title="Boy" src="<?php echo e(asset('image/vector/boy2.png')); ?>" style=
                                        "width:100%; height:100%"> -->
                                        </div>
                                      </a>
                                    </td>
                                  </tr>
                                
                                
                                  <tr>
                                    <?php $__currentLoopData = $pc_category->sub_parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subparent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($subparent->parent_category_name !="Toodler"): ?>
                                      
                                        <td >
                                          <?php $__currentLoopData = $subparent->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <i class="fas fa-angle-double-right"></i>
                                            <a 
                                              href="<?php echo e(route('shop.categoryProdcuts1', [$subparent->parent_category_slug,  $our_cat->category_slug  ])); ?>" class="btn btn-primary"><?php echo e($our_cat->category_name); ?>

                                            </a>
                                              <br>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                  
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                  </tr>
                                
                                </tbody>
                              </table>
                            </li>
                          </ul>
                        </div>
                      </li>
                    <?php else: ?>
                      <li class="dropdown mega-cat">
                        <a href="<?php echo e(route('shop.categoryProdcuts',$pc_category->parent_category_slug)); ?>"><?php echo e($pc_category->parent_category_name); ?>

                        </a>
                        <div class="dropdown-menu" >
                            
                            <?php if($pc_category->our_categories && !empty($pc_category->our_categories)): ?>
                            
                              <?php 
                            
                                $count_index = 0;
                              
                                $max_count = count($pc_category->our_categories)/3;
                                $cats1 = array_slice($pc_category->our_categories,$count_index, $max_count);
                                
                                $count_index = $max_count;
                                $max_count = $max_count;
                                  $cats2 = array_slice($pc_category->our_categories,$count_index, $max_count);

                                  $count_index = count($cats1)+count($cats2);
                                $max_count = count($pc_category->our_categories);
                                  $cats3 = array_slice($pc_category->our_categories,$count_index, $max_count);
                            
                              ?>
                                
                              <ul>
                                <?php $__currentLoopData = $cats1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li class="d-flex justify-content-center align-items-center pl-3">
                                    <i class="fas fa-angle-double-right" style="color:#fff;" ></i>
                                    <a  
                                      href="<?php echo e(route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug])); ?>"><?php echo e($category->category_name); ?>

                                    </a>
                                  </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                              <ul>
                              <?php $__currentLoopData = $cats2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                                <li class="d-flex justify-content-center align-items-center pl-3">
                                  <i class="fas fa-angle-double-right" style="color:#fff;" ></i>
                                  <a href="<?php echo e(route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug  ])); ?>"><?php echo e($category->category_name); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                              <ul>
                              <?php $__currentLoopData = $cats3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                                <li class="d-flex justify-content-center align-items-center pl-3">
                                  <i class="fas fa-angle-double-right" style="color:#fff;" ></i>
                                  <a href="<?php echo e(route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug  ])); ?>"><?php echo e($category->category_name); ?>

                                  </a>
                                </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          
                          <?php endif; ?>
                        </div>
                      </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              <li class="contact-link">
                <a href="<?php echo e(route('shop.offerProducts','today-sale')); ?>">Today Sales</a>
              </li>

              <li class="contact-link">
                <a href="<?php echo e(route('shop.offerProducts','new-arrival')); ?>" >New Arrivals</a>
              </li>
           
              <li class="menu_brands dropdown">
                <a href="<?php echo e(route('brands')); ?>">Brands</a>
                <div class="dropdown-menu">
                      
                    <?php 
                    $brands_count = 0;
                    ?>
                    <div class="row" style="margin-left: 2rem">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    $brands_count++;
                    if($brands_count>10)
                    {
                      break;
                    }
                    ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6"><a href="/shop/<?php echo e($brand->store_slug); ?>"><img src="/logos/<?php echo $brand->store_logo; ?>" class="logo" height="40" width="50" style="object-fit: scale-down;width:-webkit-fill-available;" title="<?php echo e($brand->store_name); ?>" alt="<?php echo e($brand->store_name); ?>" /></a><a href="/shop/<?php echo e($brand->store_slug); ?>"><?php echo e($brand->store_name); ?></a></div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <p>
                   <a style="margin-left: 2rem;padding-bottom:10px;color: lightgrey" href="<?php echo e(route('brands')); ?>" class="">More Brands</a>
                 </p> 
                </div>
              </li>

              <li class="menu_brands dropdown"><a href="<?php echo e(route('online_stores')); ?>">Online Stores</a>
                <div class="dropdown-menu">                      
                  <?php 
                  $store_count = 0;
                  ?>
                  <div class="row" style="margin-left: 2rem">
                  <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                  $store_count++;
                  if($store_count>10){
                    break;
                  }
                  ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6">
                    <a href="/shop/<?php echo e($store->store_slug); ?>">
                      <img src="/logos/<?php echo $store->store_logo; ?>" height="40" width="50" style="object-fit: scale-down;width:-webkit-fill-available;"  class="logo" title="<?php echo e($store->store_name); ?>" alt="<?php echo e($store->store_name); ?>" />
                    </a>
                    <a href="/shop/<?php echo e($store->store_slug); ?>"><?php echo e($store->store_name); ?></a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <p>
                   <a style="padding-bottom:10px;margin-left: 2rem;color: lightgrey" href="<?php echo e(route('online_stores')); ?>" class="">More Online Stores</a>
                     
                  </p>
                </div>
              </li>
             
              <li class="dropdown">
                <a href="#">Special Offers
                </a>
                <div class="dropdown-menu" >
              
                  <?php                       
                  $count_index = 0;
                  $max_count = count($offer_types)/2;
                  $cats1 = array_slice($offer_types,$count_index, $max_count);
                  $cats2 = array_slice($offer_types,count($cats1), count($offer_types));       
                  ?>
                  <ul>
                    <?php $__currentLoopData = $cats1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $offer_type = (Object) $offer_type; ?>
                   
                      <li class="d-flex justify-content-center align-items-center pl-3">
                        <i class="fas fa-angle-double-right" style="color:#fff;" ></i>
                        <a href="<?php echo e(route('shop.offerProducts',$offer_type->offer_type_slug)); ?>"><?php echo e($offer_type->offer_type_name); ?></a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                 <ul>
                  <?php $__currentLoopData = $cats2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $offer_type = (Object) $offer_type; ?>
                  
                    <li class="d-flex justify-content-center align-items-center pl-3">
                      <i class="fas fa-angle-double-right" style="color:#fff;" ></i>
                      <a href="<?php echo e(route('shop.offerProducts',$offer_type->offer_type_slug)); ?>"><?php echo e($offer_type->offer_type_name); ?></a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              </li>
              <li class="contact-link">
                <a href="<?php echo e(route('businesses')); ?>" >Businesses</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>

      <!-- Main Menu End-->
    <input type="hidden" id="prev_url" value="<?php echo e($_SERVER['REQUEST_URI']); ?>" />

    <div class="modal fade" id="modal_product_details" role="document">
     
      <div class="modal-dialog modal-lg">
        
          <!-- Modal content-->
          <div class="modal-content">
      
            <div class="modal-body" id="content-div-product">
              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary"  onClick="hideModalById('modal_product_details')">Close</button>
            </div>

          </div>

      </div>

    </div>

     <div class="modal fade" id="modal_product_comparison" role="document">
     
      <div class="modal-dialog modal-lg">
        
          <!-- Modal content-->
          <div class="modal-content">
      
            <div class="modal-body" id="content-div-comparison" style="overflow-y: scroll;
    max-height: 450px;">
                
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary"  onClick="hideModalById('modal_product_comparison')">Close</button>
            </div>

          </div>

      </div>

    </div>
    <div class="modal fade" id="modal_product_message" role="document">
     
      <div class="modal-dialog modal-sm">
        
          <!-- Modal content-->
          <div class="modal-content">
                 
            <div class="modal-body" id="content-div-message" >
              <span onclick="hideModalById('modal_product_message')" style="float: right;
              cursor: pointer;
              color: #000;" >
                       <i onclick="hideModalById('modal_product_message')" style="font-size: 21px;" class="fas fa-times"></i></span>
                <div id="modal_message" style="padding:10px">
                </div>
            </div>

           
          </div>

      </div>

    </div>

     <div class="modal fade" id="modal_product_alert" role="document">
     
      <div class="modal-dialog modal-lg">
        
          <!-- Modal content-->
          <div class="modal-content">
      
            <div class="modal-body" id="content-div-alert" style="overflow-y: scroll;max-height: 450px;">
                
            </div>

           
          </div>

      </div>

    </div>

  </div>
    <?php echo $__env->yieldContent('content'); ?>
 
  <footer id="footer">
    <div class="fpart-first ">
      <div class="container default-width mx-auto">
        <div class="row">
          <div class="contact col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <h5>About Derss Ads</h5>
            <p> On Dress Ads you can find the latest ads about dresses of vast variety from famous online stores and brands.</p>
            <img alt="" src="<?php echo e(asset('image/logo.png')); ?>">
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Information</h5>
            <ul>
              <li><a href="/shop/men">Men</a></li>
                    <li><a href="/shop/women">Women</a></li>
                      <li><a href="/shop/baby">Baby</a></li>
                      <li><a href="/shop/girl">Girls</a></li>
                  <li><a href="/shop/boy">Boys</a></li>
            </ul>
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Deals & Offers</h5>
            <ul>
               <li><a href="/shop/today-sale">Todays Sales</a></li>
                  <li><a href="/shop/new-arrival">New Arrivals</a></li>
                  <li><a href="/shop/promo">Special Offers</a></li>
            </ul>
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Other</h5>
            <ul>
               <li><a href="<?php echo e(route('site_map')); ?>">Site Map</a></li>
               <li><a href="<?php echo e(route('businesses')); ?>">Businesses</a></li>
             <li><a href="<?php echo e(route('brands')); ?>">Brands</a></li>
                  <li><a href="<?php echo e(route('online_stores')); ?>">Online Stores</a></li>
              
            </ul>
          </div>
          <div class="column col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h5>Newsletter</h5>
            <div class="form-group">
            <label class="control-label" for="subscribe">Sign up to receive latest news and updates.</label>
            <input id="signup" type="email" required="" placeholder="Email address" name="email" class="form-control">
            </div>
            <input type="submit" value="Subscribe" class="btn btn-primary">
          </div>
        </div>
      </div>
    </div>
    <div class="fpart-second">
      <div class="container default-width mx-auto">
        <div id="powered" class="clearfix">
          <div class="powered_text pull-left flip">
            <p>Dress Ads © 2021 | Software Pattern</p>
          </div>
          <div class="social pull-right flip"> <a href="#" target="_blank"> <img data-toggle="tooltip" src="<?php echo e(asset('image/socialicons/facebook.png')); ?>" alt="Facebook" title="Facebook"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="<?php echo e(asset('image/socialicons/twitter.png')); ?>" alt="Twitter" title="Twitter"> </a>  <a href="#" target="_blank"> <img data-toggle="tooltip" src="<?php echo e(asset('image/socialicons/pinterest.png')); ?>" alt="Pinterest" title="Pinterest"> </a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="<?php echo e(asset('image/socialicons/rss.png')); ?>" alt="RSS" title="RSS"> </a> </div>
        </div>
       
      </div>
    </div>
    <div id="back-top"><a data-toggle="tooltip" title="Back to Top" href="javascript:void(0)" class="backtotop"><i class="fa fa-chevron-up"></i></a></div>
  </footer>
  <!--Footer End-->
</div>
<!-- JS Part Start-->
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('revolution/js/jquery.themepunch.tools.min.js?rev=5.0')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('revolution/js/jquery.themepunch.revolution.min.js?rev=5.0')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.easing-1.3.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dcjqaccordion.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.elevateZoom-3.0.8.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/swipebox/lib/ios-orientationchange-fix.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/swipebox/src/js/jquery.swipebox.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
<!-- JS Part End-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>

<script type="text/javascript" src="<?php echo e(asset('js/jquery.toaster.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/general_functions.js')); ?>"></script>
<script>  



jQuery(document).ready(function() {  

$("#zoom_01").elevateZoom({
  gallery:'gallery_01',
  cursor: 'pointer',
  galleryActiveClass: 'active',
  imageCrossfade: true,
  zoomWindowFadeIn: 500,
  zoomWindowFadeOut: 500,
  lensFadeIn: 500,
  lensFadeOut: 500,
  loadingIcon: 'image/progress.gif'
  }); 
//////pass the images to swipebox
$("#zoom_01").bind("click", function(e) {
  var ez =   $('#zoom_01').data('elevateZoom');
  $.swipebox(ez.getGalleryList());
  return false;
});

   jQuery("#slider1").revolution({
      sliderType:"standard",
      sliderLayout:"fullwidth",
      delay:9000,
      navigation: {
      onHoverStop: "off",
          arrows:{enable:true},
      touch: {
          touchenabled: "on",
          swipe_threshold: 75,
          swipe_min_touches: 1,
          swipe_direction: "horizontal",
          drag_block_vertical: false
      },
      bullets: {
          enable: true,
          hide_onmobile: true,
          style: "hermes",
          hide_onleave: false,
          direction: "horizontal",
          h_align: "center",
          v_align: "bottom",
          h_offset: 20,
          v_offset: 20,
          space: 5,
          tmp: ''
      },
      },
    
                
     gridwidth:1230,
      gridheight:480
    });   


         $(".search-select").selectize({
          sortField: 'text'
      });
}); 
</script>

</body>
</html>

<script type="text/javascript">


      <?php if(isset($selected) && isset($selected_sub1)): ?>
    
        <?php if(ucfirst($selected) == "Girl" || ucfirst($selected_sub1) == "Girl" || ucfirst($selected_sub1) == "Boy" || ucfirst($selected) == "Boy" || ucfirst($selected) == "Baby" || ucfirst($selected_sub1) == "Baby"): ?>
         $("#kids").show();
        <?php endif; ?>
       $("#<?=Str::slug($selected_sub1)?>").show();
       $("#<?=Str::slug($selected)?>").show();
       
       <?php elseif(isset($selected) && !isset($selected_sub1)): ?>
    
        <?php if(ucfirst($selected) == "Girl"   || ucfirst($selected) == "Boy" || ucfirst($selected) == "Baby"): ?>
         $("#kids").show();
        <?php endif; ?>
       $("#<?=Str::slug($selected)?>").show();
     
      <?php elseif(isset($selected_sub1) &&  !isset($selected)): ?>
    
        <?php if(ucfirst($selected_sub1) == "Girl" || ucfirst($selected_sub1) == "Boy" ||  ucfirst($selected) == "Baby" ): ?>
         $("#kids").show();
        <?php endif; ?>
       $("#<?=Str::slug($selected_sub1)?>").show();
       
      <?php endif; ?>
     
     
//  $("#category_div").hide();
  //$("#price_div").hide();
  $("#sub_category_div").hide();
  //$("#color_div").hide();
  //$("#store_div").hide();
  //$("#size_div").hide();
  //$("#brand_div").hide();
    
  
   function hideModal(){
      $("#myModal").modal('hide');
    }

  

    $("#parent_category").change(function(event){


      if(event.target.value == "3"){

        $("#sub_category_div").show();
      }else{
        $("#sub_category_div").hide();
      }

      // let parent_category = $("#parent_category").val();
  
      // let _token   = $('meta[name="csrf-token"]').attr('content');

      // $.ajax({
      //   url: "<?php echo e(route('get_our_categories')); ?>",
      //   type:"POST",
      //   data:{
      //     parent_category:parent_category,
         
      //     _token: _token
      //   },
      //   success:function(response){
          
      //     if(response && response !="") {
      //       $("#category_name").html(response);
      //     }
      //   },
      //  });
  }
  );

    $("#store_id").change(function(event){

      // event.preventDefault();
      // let store_id = $("#store_id").val();
      // let _token = $("meta[name='csrf-token']").attr('content');

      // $.ajax({
      //   url:"<?php echo e(route('get_colors')); ?>",
      //   type:"post",
      //   data:{
      //     store_id : store_id,
      //     _token : _token
      //   },
      //   success:function(response){
      //     if(response && response !="NOCOLOR"){
      //       $("#colors").html(response);
      //     }else if(response && response =="NOCOLOR"){
      //       $("#colors").html("Colors not available");
      //     }
      //   }

      // });

      // $.ajax({
      //   url:"<?php echo e(route('get_sizes')); ?>",
      //   type:"post",
      //   data:{
      //     store_id : store_id,
      //     _token : _token
      //   },
      //   success:function(response){
      //     if(response && response !="NOSIZE"){
      //       $("#sizes").html(response);
      //     }else if(response && response =="NOSIZE"){
      //       $("#sizes").html("Sizes not available");
      //     }
      //   }
        
      // });
    });




</script>
<?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/layouts/app.blade.php ENDPATH**/ ?>