@extends('layouts.app')

@section('content')

<link rel="stylesheet" type="text/css" href="{{asset('css/business__styles/business__details__styles.css')}}">

<div class="business__detail_page__body">

    <div class="product__detail_top_section">
        <div class="row pd__r1">
                                                        <!-- Logo -->
            <div class="col-lg-2 col-md-2 col-sm-5 pd__logo__container d-flex justify-content-end align-items-center">
                    <div class="product__logo">
                        <img src="{{asset('image/1.jpg')}}" alt="" style="width:100%; height:100%;">
                    </div>
            </div>

            <div class="col-lg-10 col-md-10 col-sm-7">
                <div class="row">

                    <div class="col-lg-9 col-md-8 col-sm-5 product__detail__col1 ">

                        <div class="product__details__upper_sec">
                            <div class="product__title pb-3">
                                <span>HP Laptop</span>
                            </div>

                            <div class="product__store_title">
                                <span>Fairview Mall</span>
                            </div>

                            <div class="product__address d-flex justify-content-start align-items-center">
                                <p class="address__info m-0">2006-1800 Sheppard Ave E, North York, ON M2J 5A7</p>
                                <a href="" class="product__link ">Get Directions >></a>
                            </div>
                        </div>

                        <div class="product__details__lower d-flex justify-content-start align-items-center flex-wrap">
                                            <!-- phone number  -->
                            <a href="" class="product__info__btn d-flex justify-content-between align-items-center m-2">
                                <i class="fas fa-phone px-2"></i>
                                <span>Phone number</span>
                            </a>
                                        <!-- message  -->
                            <a href="" class="product__info__btn d-flex justify-content-between align-items-center m-2">
                                <i class="fas fa-comment-dots px-2 "></i>
                                <span>Message</span>
                            </a>
                                            <!-- direction  -->
                            <a href="" class="product__info__btn d-flex justify-content-between align-items-center m-2">
                            <i class="fas fa-map-marker-alt px-2 "></i>
                                <span>Direction</span>
                            </a> 
                                            <!-- website  -->
                            <a href="" class="product__info__btn d-flex justify-content-between align-items-center m-2">
                                <i class="fas fa-link px-2 "></i>
                                <span>Website</span>
                            </a>

                            <div class="store__timing pl-3">
                                <a>Opening at 10:00 am, <span class="seeAll">See all hours</span></a>
                            </div>
                        </div>


                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-7 product__detail__col2 d-flex justify-content-end align-items-end pb-2">

                        <div class="product__details__shopping d-flex flex-column justify-content-end align-items-end">

                            <i class="fas fa-5x fa-shopping-cart my-2"></i>
                            <div class="rating_section d-flex justify-content-end align-items-center">
                                <i class="fas px-1 fa-star full__rating"></i>
                                <i class="fas px-1 fa-star full__rating"></i>
                                <i class="fas px-1 fa-star full__rating"></i>
                                <i class="fas px-1 fa-star full__rating"></i>
                                <i class="fas fa-star-half-alt half__rating"></i>
                            </div>
                           
                            <a href="" class="m-0 read__review">Read a reviews >></a>

                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>

        <!-- add photos section  -->

    <div class="product__photos__section">
        <form action="">
            <div class="row">

                <div class="col-lg-2 col-md-2 col-sm-4 d-flex justify-content-end align-items-center p-1">
                    <div class="product__img">
                        <img src="{{asset('image/add1.jpg')}}" alt="" style="width:100%; height:100%;">
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 p-1">
                    <div class="add_product__img d-flex flex-column justify-content-center align-items-center">
                      <input type="file" id="product__image" class ="d-none" name="product__image">
                      <p class="m-0 p-0  pb-4 bus__like__ques">Like this business?</p>
                      <label for="product__image" class="add__option">ADD A PHOTO</label>
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 p-1">
                    <div class="product__img">
                        
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 p-1">
                    <div class="product__img">
                       
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 p-1">
                    <div class="product__img">
                        
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-4 p-1">
                    <div class="product__img">
                        
                    </div>
                </div>

            </div>
        </form>
    </div>

        <!-- details and descriptions section  -->
    <div class="product__description__section my-5">
        <div class="row">
                                <!-- DESCRIPTION  -->
            <div class="col-lg-8 col-md-8 col-sm-12">
                <h3 class="pb-2">Details & Description</h3>
                <p>
                    THE HOTTEST DRESS STORE IN TORONTO. WE CARRY THE LARGEST SELECTION OF PROM DRESSES IN TORONTO. 
                    WE ALSO CARRY WEDDING GOWNS BRIDESMAIDS DRESSES & PARTY D...
                </p>
                <h5 class="pt-4 ">Products and Services</h5>
                <div class="w-50"> <hr></div>
                <p>Top, Women's Clothing Store, #shoplocalonline</p>

                <h2 class="pt-4">Useful Information</h2>
                <h4 class="py-2">Opening Hours</h4>
                <div class="w-50"> <hr></div>

                <div class="opening__hours__timing " id ="openingTiming">
                    <table class="table table-striped ">

                        
                        <tbody id="tableBody1">
                            <tr class=""onclick="showBody2()" >
                                <th scope="col" class="topDay">Monday</th>
                                <td scope="col" >10:00 am to 9:00 pm <i class="fas fa-angle-down pl-3"></i></td>
                            </tr>
                        </tbody>

                        <tbody id ="tableBody2" class="hideBody">
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="topDay">Monday</th>
                                <td scope="col"class="topDayTime">10:00 am to 9:00 pm <i class="fas fa-angle-down pl-3"></i></td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col"class="Days">Tuesday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="Days">Wednesday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="Days">Thursday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="Days">Friday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="Days">Saturday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                            <tr class="" onclick="showBody2()">
                                <th scope="col" class="Days">Sunday</th>
                                <td scope="col">10:00 am to 9:00 pm</td>
                            </tr>
                        </tbody>

                    </table>
                </div>

                            <!-- rates and payment method section  -->
                <div class="row mt-5">
                                    <!-- rates  -->
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <h2>Rates</h2>
                        <div class="w-100"> <hr></div>
                        <p class="rate__price">$11 To $25,</p>

                    </div>
                                    <!-- payment method  -->
                    <div class="col-lg-6 col-md-6 col-sm-12">
                   
                        <h2>Methods of Payment:</h2>
                        <div class="w-100"> <hr></div>
                        <div class="d-flex justify-content-start align-items-center">
                            
                            <div class="payment__icons mr-4"data-toggle="tooltip" data-placement="top" title="MASTERCARD">
                                <a href=""style="width:100%;height:100%;">
                                    <img src="{{asset('image/icons/mastercard.svg')}}" alt="" style="width:100%;height:100%;">
                                </a>
                                
                            </div>

                            <div class="payment__icons"data-toggle="tooltip" data-placement="top" title="VISA">
                                <a href=""style="width:100%;height:100%;">
                                    <img src="{{asset('image/icons/visa.svg')}}" alt="" style="width:100%;height:100%;">
                                </a>
                                
                            </div>
                        </div>

                    </div>
                                        <!-- social media  -->
                                                                            
                    <div class="col-lg-6 col-md-6 col-sm-12 mt-5">
                   
                        <h2>Social Media</h2>
                        <div class="w-100"> <hr></div>
                        <div class="d-flex justify-content-start align-items-center">
                            
                            <div class="payment__icons mr-4"data-toggle="tooltip" data-placement="top" title="facebook">
                                <a href=""style="width:100%;height:100%;">
                                    <img src="{{asset('image/icons/fb.png')}}" alt="" style="width:100%;height:100%;">
                                </a>
                                
                            </div>

                        </div>

                    </div>
                </div>

            </div>
                                <!-- LOCATION  -->
            <div class="col-lg-4 col-md-4 col-sm-12">
                <h2>Location</h2>
                
                <div class="googleMap " id ="map1">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387190.2799160891!2d-74.25987584510595!3d40.69767006338158!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1638856968352!5m2!1sen!2s" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </div>

            <!-- rating and reviews section  -->
    <div class="lower__section">
        <div class="rating__reviews__section1 d-flex justify-content-center align-items-center flex-wrap">

                    <!-- add to fav btn  -->
            <div class="add__Fav__btn mt-2">
                <a href="">
                    <div class="add__btn d-flex justify-content-around align-items-center">
                        <i class="far fa-heart pr-3"></i>
                        <p class="p-0 m-0 btn__title">Add to Favourites </p>
                    </div>
                </a>
            </div>
                    <!-- write a review btn  -->
            <div class="add__Fav__btn mt-2">
                <a href="">
                    <div class="add__btn d-flex justify-content-around align-items-center">
                        <i class="fas fa-star star__icon pr-3"></i>
                        <p class="p-0 m-0 btn__title">Write a review </p>
                    </div>
                </a>
            </div>
                    <!-- Share btn  -->
            <div class="add__Fav__btn mt-2">
                <a href="">
                    <div class="add__btn d-flex justify-content-around align-items-center">
                        <i class="fas fa-share-alt pr-3 share__icons"></i>
                        <p class="p-0 m-0 btn__title">Share </p>
                    </div>
                </a>
            </div>
                    <!-- Suggest an update btn  -->
            <div class="add__Fav__btn  mt-2">
                <a href="">
                    <div class="add__btn d-flex justify-content-around align-items-center">
                        <i class="far fa-heart pr-3"></i>
                        <p class="p-0 m-0 btn__title">Suggest an update </p>
                    </div>
                </a>
            </div>

        </div>
        <div class="rating__reviews__section2">

            <div class="row w-100">

                <div class="col-lg-9 col-md-8 col-sm-12 business__rating">

                    <div class="d-flex justify-content-between align-items-center">
                        <h2>Ratings & Reviews - Norma Reed</h2>
                            <!-- Button trigger modal -->
                        <button 
                            type="button" 
                            class="modal__open" 
                            data-toggle="modal" 
                            data-target="#staticBackdrop">
                            Write A Review
                        </button>
                    </div>

                            <!-- rate it  -->
                    <div class="d-flex flex-column justify-content-center align-items-center rate__it">

                        <h3 id="ratting__title">How would you rate this business?</h3>
                        <div class="w-100"> <hr></div>
                        <div class="d-flex justify-content-center align-items-center rating__stars">
                            <i class="fas px-1 fa-2x fa-star " id="star1"></i>
                            <i class="fas px-1 fa-2x fa-star " id="star2"></i>
                            <i class="fas px-1 fa-2x fa-star " id="star3"></i>
                            <i class="fas px-1 fa-2x fa-star " id="star4"></i>
                            <i class="fas px-1 fa-2x fa-star " id="star5"></i>
                        </div>
                    </div>

                            <!-- rating count  -->
                    <div class="d-flex justify-content-center align-items-center rating__count my-3">
                       <a href=""><span>1 </span> <span>Rating & </span><span>1</span><span>Review</span></a> 
                    </div>

                    <div class="w-100"> <hr></div>

                    <div class="d-flex justify-content-center align-items-center rating__values my-3 pb-3">
                        <div class="row w-100">
                            <div class=" col-lg-6 col-md-6 col-sm-12 d-flex flex-column justify-content-center align-items-center">

                                <div class="d-flex justify-content-center align-items-center">
                                    <p class="avg__rate">5</p>
                                    <p class="total__rate">/5</p>
                                </div>

                                <div class="d-flex justify-content-center align-items-center">
                                    <i class="fas px-1 fa-star rating__stars"></i>
                                    <i class="fas px-1 fa-star rating__stars"></i>
                                    <i class="fas px-1 fa-star rating__stars"></i>
                                    <i class="fas px-1 fa-star rating__stars"></i>
                                    <i class="fas px-1 fa-star rating__stars"></i>
                                </div>

                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 d-flex flex-column justify-content-center align-items-start">
                                                <!-- Excellent -->

                                <div class="rating__single__values d-flex">
                                    <p class="m-0 p-0 pr-3 rating__values__title">Excellent</p> 
                                    <p class="m-0 p-0 mr-2" style="width:100px; background-color:gold;"></p> 
                                    <p class="m-0 p-0 pr-3 rating__values__title" >1</p> 
                                    
                                </div>
                                
                                                <!-- Very Good -->
                                <div class="rating__single__values d-flex justify-content-start align-items-center">
                                    <p class="m-0 p-0 pr-3 rating__values__title">Very Good</p> 
                                    <p class="m-0 p-0 mr-2" style="width:0px; background-color:gold;"></p> 
                                    <p class="m-0 p-0 pr-3 rating__values__title" >1</p> 
                                    
                                </div>

                                                <!-- Average -->
                                <div class="rating__single__values d-flex">
                                    <p class="m-0 p-0 pr-3 rating__values__title">Average</p> 
                                    <p class="m-0 p-0 mr-2" style="width:0px; background-color:gold;"></p> 
                                    <p class="m-0 p-0 pr-3 rating__values__title" >1</p> 
                                    
                                </div>

                                                <!-- Poor -->
                                <div class="rating__single__values d-flex">
                                    <p class="m-0 p-0 pr-3 rating__values__title">Poor</p> 
                                    <p class="m-0 p-0 mr-2" style="width:0px; background-color:gold;"></p> 
                                    <p class="m-0 p-0 pr-3 rating__values__title" >0</p> 
                                    
                                </div>

                                                <!-- Terrible -->
                                <div class="rating__single__values d-flex">
                                    <p class="m-0 p-0 pr-3 rating__values__title">Terrible</p> 
                                    <p class="m-0 p-0 mr-2" style="width:0px; background-color:gold;"></p> 
                                    <p class="m-0 p-0 pr-3 rating__values__title" >0</p> 
                                    
                                </div>


                            </div>
                        </div>


                    </div>

                    <div class="w-100 py-3"> <hr></div>

                                <!-- comments section  -->
                    <div class="row w-100">

                        <div class="col-lg-2 col-md-3 col-sm-6">
                            <div class="w-100 d-flex justify-content-center align-items-center">
                                    <div class="commenter__img">
                                        <img src="{{asset('image/1.jpg')}}" alt="" 
                                        style="width:100%;height:100%; border-radius: 50%;">
                                    </div>
                            </div>
                        </div>

                        <div class="col-lg-10 col-md-9 col-sm-6">
                                        <!-- commenter Info  -->
                            <div class="w-100 d-flex justify-content-between align-items-center">
                                <div class="commenter__name__rating d-flex justify-content-start align-items-center">
                                    
                                    <div class="commenter__rating d-flex mr-2 align-items-center">
                                        <i class="fas px-1 fa-star rating__stars"></i>
                                        <i class="fas px-1 fa-star rating__stars"></i>
                                        <i class="fas px-1 fa-star rating__stars"></i>
                                        <i class="fas px-1 fa-star rating__stars"></i>
                                        <i class="fas px-1 fa-star rating__stars"></i>
                                    </div>

                                    <div class="commenter__name d-flex  justify-content-start align-items-center">
                                       <span class="mr-2">By</span> <span class="mr-2 ">RachelandTom Roberto</span>
                                    </div>


                                </div>
                                <div class="commenter__date_time d-flex justify-content-center align-items-center">
                                    <span> March 24, 2019</span>
                                </div>
                            </div>
                                        <!-- comment text  -->
                            <div class="w-100 py-3">
                                <p>After an endless search for a prom dress, we ended up at Norma Reeds, well this store is great, a lot of dress choices and the best Sales person ever!! We live in Niagara Falls, and I would make the drive out there just for Jana!! What an amazing, caring, lovely woman. She was absolutely awesome, so helpful, so kind, she made us feel like part of her family!! You have a true gem of an employee there!!! Thank you so much Jana, I will always remember you as a great part of my daughters prom!!! We</p>
                            </div>
                                        <!-- other reactions  -->
                            <div class="other__reactions d-flex justify-content-start align-items-center">

                                                    <!-- helpful  -->
                                <div class="reaction  mr-3">
                                    <a href="" class="d-flex justify-content-start align-items-center">
                                        <i class="far  mr-2 fa-thumbs-up"></i>
                                        <span class="mr-2 ">Helpful</span>
                                        <span class="mx-2 py-2 px-4 reaction__count">1</span>
                                    </a>

                                </div>
                                                    <!-- report  -->
                                <div class="reaction  mr-3" id="report__icon">

                                    <a href="" class="d-flex justify-content-start align-items-center">
                                        <i class="far  fa-flag mr-2"></i>
                                        <span class="mr-2 py-2">Report</span>
                                    </a>

                                </div>

                            </div>
                                                    <!-- To Report -->
                            <div class="other__reactions d-flex justify-content-start align-items-center my-4 " >

                                                    <!-- helpful  -->
                                <div class="reaction d-flex justify-content-start align-items-center mr-3 hideBody" >
                                    <i class="fas fa-comment-dots  mr-2 "></i>
                                    <span class="mr-2 ">Are you the owner?</span>

                                    <span class="mr-2 font-weight-bold">
                                        <a href="">Reply</a>                                        
                                    </span>

                                    <span class="mr-2 ">or</span>
                                    <span class="mr-2 font-weight-bold">
                                        <a href="">Contact</a>
                                    </span>
                                       
                                </div>
                                                   
                            </div>
                            
                        </div>
                    </div>

                </div>

                <div class="col-lg-3 col-md-4 col-sm-12 pl-2 pl-md-5 mt-md-5">
                    <h4>Related Searches</h4>
                    <div class="w-75"> <hr></div>
                    <a href="">Dresses in North York >></a>
                    <h4>Related Articles to Norma Reed</h4>
                    <div class="w-75"> <hr></div>
                    <a href="">Toronto's best vintage shops for winter gear</a>
                    <a href="">Dresses in North York >></a>
                    <a href="">Toronto's best vintage shops for winter gear</a>
                    <a href="">Dresses in North York >></a>
                </div>
            </div>
                        <!-- rate it  -->

        </div>

    </div>

        <!-- ######### write a reviews modal start########## -->
                        <!-- Modal -->
            <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class=" modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg ">
                    <!-- modal-lg -->
                <div class="modal-content">
                    <div class="modal-header" id="Rating__reviews__modal">
                    <h5 class="modal-title" id="staticBackdropLabel">Ratings and Reviews Norma Reed</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>

                    <form action="">
                        <div class="modal-body" id ="review__modal">

                            <h4 class="my-2">Overall, how would you describe your experience?</h4>

                                    <!-- rating  -->

                            <div class="d-flex w-100 my-5">
                            
                                <div class="d-flex justify-content-center align-items-center mod__rating">

                                    <i class="fas px-1 fa-2x fa-star " id="star__mod__1"></i>
                                    <i class="fas px-1 fa-2x fa-star " id="star__mod__2"></i>
                                    <i class="fas px-1 fa-2x fa-star " id="star__mod__3"></i>
                                    <i class="fas px-1 fa-2x fa-star " id="star__mod__4"></i>
                                    <i class="fas px-1 fa-2x fa-star " id="star__mod__5"></i>
                                </div>

                                <div class="mod__rating__title ml-3 d-flex justify-content-start align-items-center">
                                    <p class="m-0" id="mod__rating__title__opt">Choose a rating</p>
                                </div>

                            </div>

                            <div class="d-flex w-100 mt-3">
                                <h4>Anything to share?</h4>
                            </div>
                                                    <!-- textarea section  -->
                            <div class="d-flex w-100 my-3 flex-column">
                                <textarea id="" class="mod__review__text" name="review" rows="4" maxlength="500" > Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestias nam expedita assumenda, odit neque pariatur. Asperiores, voluptatem ratione in recusandae eum omnis quaerat eos amet incidunt non beatae deleniti! Recusandae!</textarea>
                                <div class="d-flex justify-content-end align-items-center">
                                    <p>500</p>
                                </div>
                            </div>
                                                <!-- add a photo  -->
                            <div class="d-flex w-100 my-3">
                                <h4>Add a photo</h4>
                            </div>

                                    <!-- upload a photo  -->
                            <div class="upload__photo">
                                <label for="upload__pic">
                                    <div class="photo__label d-flex justify-content-center align-items-center">
                                        <img src="{{asset('image/icons/camera.png')}}" alt="" style="width: 100%; height:100%;">
                                    </div>
                                </label>
                                <input type="file" class="d-none" id ="upload__pic">
                            </div>
                                    <!-- copyright  -->
                            <div class="mod__copyRight d-flex justify-content-start align-items-center my-4">

                                <input type="checkbox" name="">
                                <span class="mx-4 p-0">I am the owner of these photos and I accept</span>
                                <a href=""class="term__of__use">terms of use</a>

                            </div>

                                    <!-- Email address  -->

                            <div class="d-flex w-100 my-3">
                                <h4>Add a photo</h4><span> (will not be displayed)</span>
                            </div>

                            <div class="d-flex w-100 my-3">
                                <h4>Your email address</h4><span> (will not be displayed)</span>
                            </div>
                            <div class="d-flex w-100 my-3">
                            <input type="email" class="mod__email" placeholder="Enter your email">
                            </div>




                        </div>

                        <div class="modal-footer">

                            <button type="button" class=" submit__modal" data-dismiss="modal">Cancel</button>
                            <input type="submit" class="submit__modal" value="Submit">

                        </div>
                    </form>
                </div>
                </div>
            </div>


        <!-- ######### write a reviews modal end ########## -->


    <script>
        function showBody2()
        {
            let tBody1 = document.getElementById("tableBody1");
            tBody1.classList.toggle("hideBody");

            let tBody2 = document.getElementById("tableBody2");
            tBody2.classList.toggle("hideBody");

            let tBody = document.getElementById("openingTiming");
            tBody.classList.toggle("tableBorder");
        }



        

        // functions for map 

        function initMap()
        {
            var location = {lat:-25.363, lag: 131.044};
            var map = new google.maps.Map(document.getElementById("map"),{
                zoom:4,
                center:location
            });

        }
    </script>

    <script>
        $(document).ready(function(){

            // on hover over 1st star 
        $("#star1").hover(function(){
            $(this).css("color", "gold");
            $('#ratting__title').text("Terrible");

            }, function()
            {
                $(this).css("color", "black");             
                $('#ratting__title').text("How would you rate this business?");
            });

            // on hover over 2nd star 
        $("#star2").hover(function(){
            $("#star1").css("color", "gold");
            $(this).css("color", "gold");
            $('#ratting__title').text("Poor");

            }, function()
            {
                $("#star1").css("color", "black");
                $(this).css("color", "black");             
                $('#ratting__title').text("How would you rate this business?");
            });

            // on hover over 3rd star 
        $("#star3").hover(function(){
            $("#star1").css("color", "gold");
            $("#star2").css("color", "gold");
            $(this).css("color", "gold");
            $('#ratting__title').text("Good");

            }, function()
            {
                $("#star1").css("color", "black");
                $("#star2").css("color", "black");
                $(this).css("color", "black");             
                $('#ratting__title').text("How would you rate this business?");
            });

            // on hover over 4th star 
        $("#star4").hover(function(){
            $("#star1").css("color", "gold");
            $("#star2").css("color", "gold");
            $("#star3").css("color", "gold");
            $(this).css("color", "gold");
            $('#ratting__title').text("Very Good");

            }, function()
            {
                $("#star1").css("color", "black");
                $("#star2").css("color", "black");
                $("#star3").css("color", "black");
                $(this).css("color", "black");             
                $('#ratting__title').text("How would you rate this business?");
            });

            // on hover over 5th star 
        $("#star5").hover(function(){
            $("#star1").css("color", "gold");
            $("#star2").css("color", "gold");
            $("#star3").css("color", "gold");
            $("#star4").css("color", "gold");
            $(this).css("color", "gold");
            $('#ratting__title').text("Excellent");

            }, function()
            {
                $("#star1").css("color", "black");
                $("#star2").css("color", "black");
                $("#star3").css("color", "black");
                $("#star4").css("color", "black");
                $(this).css("color", "black");             
                $('#ratting__title').text("How would you rate this business?");
            });


            // #######################  Modal hover on rating  ###########
                        // on hover over 1st star 
        $("#star__mod__1").hover(function(){
            $(this).css("color", "gold");
            $('#mod__rating__title__opt').text("Terrible");

            }, function()
            {
                $(this).css("color", "black");             
                $('#mod__rating__title__opt').text("How would you rate this business?");
            });

            // on hover over 2nd star 
        $("#star__mod__2").hover(function(){
            $("#star__mod__1").css("color", "gold");
            $(this).css("color", "gold");
            $('#mod__rating__title__opt').text("Poor");

            }, function()
            {
                $("#star__mod__1").css("color", "black");
                $(this).css("color", "black");             
                $('#mod__rating__title__opt').text("How would you rate this business?");
            });

            // on hover over 3rd star 
        $("#star__mod__3").hover(function(){
            $("#star__mod__1").css("color", "gold");
            $("#star__mod__2").css("color", "gold");
            $(this).css("color", "gold");
            $('#mod__rating__title__opt').text("Good");

            }, function()
            {
                $("#star__mod__1").css("color", "black");
                $("#star__mod__2").css("color", "black");
                $(this).css("color", "black");             
                $('#mod__rating__title__opt').text("How would you rate this business?");
            });

            // on hover over 4th star 
        $("#star__mod__4").hover(function(){
            $("#star__mod__1").css("color", "gold");
            $("#star__mod__2").css("color", "gold");
            $("#star__mod__3").css("color", "gold");
            $(this).css("color", "gold");
            $('#mod__rating__title__opt').text("Very Good");

            }, function()
            {
                $("#star__mod__1").css("color", "black");
                $("#star__mod__2").css("color", "black");
                $("#star__mod__3").css("color", "black");
                $(this).css("color", "black");             
                $('#mod__rating__title__opt').text("How would you rate this business?");
            });

            // on hover over 5th star 
        $("#star__mod__5").hover(function(){
            $("#star__mod__1").css("color", "gold");
            $("#star__mod__2").css("color", "gold");
            $("#star__mod__3").css("color", "gold");
            $("#star__mod__4").css("color", "gold");
            $(this).css("color", "gold");
            $('#mod__rating__title__opt').text("Excellent");

            }, function()
            {
                $("#star__mod__1").css("color", "black");
                $("#star__mod__2").css("color", "black");
                $("#star__mod__3").css("color", "black");
                $("#star__mod__4").css("color", "black");
                $(this).css("color", "black");             
                $('#mod__rating__title__opt').text("How would you rate this business?");
            });

            // ###################      To report ###################
            // function to hide and show to report links toReport

           
        $("#report__icon").hover(function(){
            let showLinks = document.getElementById("toReport");
            showLinks.classList.toggle("hideBody");
            

            }, function()
            {
                
            });



        });
    </script>

</div>

@endsection