<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class FilterController extends Controller
{
    //
    public function women_filter(Request $request){

    	return view('filters.women_filter');
    }

    public function men_filter(Request $request){

    	return view('filters.men_filter');
    }

    public function baby_filter(Request $request){

    	return view('filters.baby_filter');
    }


    public function boy_filter(Request $request){

    	return view('filters.boy_filter');
    }


    public function girl_filter(Request $request){

    	return view('filters.girl_filter');
    }

    public function women_dress_length(Request $request){

    	return view('filters.women_dress_length');
    }


    public function women_sleeve_type(Request $request){

    	return view('filters.women_sleeve_type');
    }

    public function girl_dress_length(Request $request){

    	return view('filters.girl_dress_length');
    }

    public function girl_sleeve_type(Request $request){

    	return view('filters.girl_sleeve_type');
    }


}
