<?php

namespace App\Http\Controllers;
use App\Models\ServiceStore;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Support\Str;
use Illuminate\Routing\Controller as BaseController;

class BusinessController extends BaseController
{

    public function  businesses(Request $request){

        $title = "Business Nearby ";
        $request_data = [];

        if($request->search_address || $request->search_business){

            $request_data = $request->all();

            $query_search = ServiceStore::query();

          
            if($request->latitude && $request->latitude !="" && $request->longitude && $request->longitude !=""){

                $query_search->selectRaw("(
                   ST_Distance_Sphere(
                        point(longitude, latitude),
                        point(?, ?)
                    ) * .000621371192) as distance, service_stores.*
                ", [
                    $request->longitude,
                    $request->latitude,
                ]);

                $query_search->whereRaw("
                   ST_Distance_Sphere(
                        point(longitude, latitude),
                        point(?, ?)
                    ) * .000621371192 
                ", [
                    $request->longitude,
                    $request->latitude,
                ]);
            }

            if($request->search_business && $request->search_business !=""){
                
                $title = $request->search_business;
                $query_search->where(function ($query) use ($request){
                    $query->where('name','like', $request->search_business.'%');
                    $query->orWhere('categories','like', $request->search_business.'%');
                });
            }

            if($request->search_address && $request->search_address !="" && $request->search_address != "Using Current Location"){
                $title .= $request->search_address;
                $addresss= $request->search_address;
                
                if(strpos($addresss, ",")){
                    
                    $address = explode(',', $addresss);

                    $query_search->where('city','like',''.$address[0].'%');

                    $query_search->where('state','like',''.$address[1].'%');

                }else{

                     $query_search->where(function($query) use ($addresss){
                        $query->where('zip_code',$addresss)->orWhere('state',$addresss)->orWhere('city','like','%'.$addresss.'%')->orWhere('street_address','like','%'.$addresss.'%');
                      
                    });
                }

               
            }

            if($request->latitude && $request->latitude !="" && $request->longitude && $request->longitude !=""){

                $query_search->orderBy('distance',"DESC");
            }

           $businesses = $query_search->paginate(10);


            return view('businesses.businesses', [
                "page_title" => $title." | Ads Network",
                "businesses" => $businesses,
                "request_data" => (object)$request_data
            ]);

        }else{


            $businesses = ServiceStore::inRandomOrder()->paginate(10);

            
            return view('businesses.businesses', [
                "page_title" => $title." | Ads Network",
                "businesses" => $businesses,
                 "request_data" => (object)$request_data
            ]);

        }

    }


    public function ac_business_search(Request $request){


        $data = $request->all();
        
        if($data && isset($data['query']) && $data['query'] !=""){

            $results = ServiceStore::selectRaw('CONCAT(name)')->where('name','LIKE',$data['query'].'%')->limit(7)->get();

              $results = ServiceStore::select(DB::raw('(CASE WHEN name like "'.$data['query'].'%" 
            THEN name 
            WHEN categories like "'.$data['query'].'%" 
            THEN categories 
             
            ELSE "" END) AS 
            search_business'))->where('name','like',$data['query'].'%')->orWhere('categories','like',$data['query'].'%')->groupBy('search_business')->limit(20)->get();

            $results = $results->toArray();
           
            $data = [];
            foreach($results as $item) 
            {
                $data[] = $item['search_business'];
            }
             return response()->json($data);

        }elseif($data && isset($data['query_address']) && $data['query_address'] !=""){

            $results = ServiceStore::select(DB::raw('(CASE WHEN zip_code = "'.$data['query_address'].'" 
            THEN zip_code 
            WHEN state like "'.$data['query_address'].'%" 
            THEN state 
            WHEN city like "'.$data['query_address'].'%"
            THEN CONCAT(city,",",state) 
            WHEN street_address like "'.$data['query_address'].'%" 
            THEN street_address 
             
            ELSE "" END) AS 
            address'))->where('zip_code',$data['query_address'])->orWhere('state',$data['query_address'])->orWhere('city','like','%'.$data['query_address'].'%')->orWhere('street_address','like','%'.$data['query_address'].'%')->groupBy('address')->limit(20)->get();
            // $collection = collect($results);
            // $result = $collection->unique()->values()->all();
            $results = $results->toArray();
           
            $data = [];
            foreach($results as $res) 
            {
                $data[] = $res['address'];
            }
             return response()->json($data);
        }

    }


    public function business_details(Request $request)
    {   
        return view ('businesses.business_details');
    }

}