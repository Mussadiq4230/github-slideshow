<?php

namespace App\Http\Controllers;
use App\Models\ServiceStore;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Support\Str;
use Illuminate\Routing\Controller as BaseController;

class BusinessController extends BaseController
{

    public function  businesses(Request $request){

    	$businesses = ServiceStore::inRandomOrder()->paginate(10);


    	$states = ServiceStore::select('state')->groupBy('state')->orderBy("state")->get();
    	$cities = ServiceStore::select('city')->groupBy('city')->orderBy("city")->get();


    	return view('businesses.businesses', [
    		"businesses" => $businesses,
    		"states" => $states,
    		"cities" => $cities
     	]);

    }

}