<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\BusinessController;
use App\Http\Controllers\ProductController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/' ,[HomeController::class ,'home']);
Route::get('/home' ,[HomeController::class ,'home'])->name('home');
Route::get('/create_lists',[HomeController::class,'create_lists'])->name('create_lists');
Route::get('/create_slugs',[HomeController::class,'create_slugs'])->name('create_slugs');
Route::get("/create_filter_modal_content",[HomeController::class,'create_filter_modal_content'])->name('create_filter_modal_content');

#Header Content
Route::post('get_our_categories', [HomeController::class ,'get_our_categories'])->name('get_our_categories');
Route::post('get_colors', [HomeController::class, 'get_colors'])->name('get_colors');
Route::post('get_sizes', [HomeController::class, 'get_sizes'])->name('get_sizes');

#Stores
Route::get('online_stores', [StoreController::class, 'online_stores'])->name('online_stores');
Route::get('brands', [StoreController::class, 'online_brands'])->name('brands');


#Products



Route::get('shop/{parent_category_slug}', ['as' => 'shop.categoryProdcuts', 'uses' => 'App\Http\Controllers\ProductController@category_products']);

Route::get('shop/{parent_category_slug}/{category_slug}', ['as' => 'shop.categoryProdcuts1', 'uses' => 'App\Http\Controllers\ProductController@category_products']);

Route::get('shop/{parent_category_slug}/{category_slug}/{sub_category}', ['as' => 'shop.categoryProdcuts2', 'uses' => 'App\Http\Controllers\ProductController@category_products']);

Route::get('shop', ['as' => 'shop.categoryProdcuts3', 'uses' => 'App\Http\Controllers\ProductController@category_products']);

Route::get('shop/{offer_type}',  ['as' => 'shop.offerProducts', 'uses' => 'App\Http\Controllers\ProductController@offer_products']);

Route::get('site_map', [HomeController::class, 'site_map'])->name('site_map');

Route::get('stores/{our_category_id}', [StoreController::class, 'stores']);
Route::get('stores/{parent_category_slug}/{our_category_id}', [StoreController::class, 'stores']);

Route::get("/get_product_details_modal_content",[HomeController::class,'get_product_details_modal_content'])->name('get_product_details_modal_content');

Route::get('/detail/{parent_category_slug}/{our_category_slug}/{product_slug}', [HomeController::class, 'product_detail'])->name('product_detail');

#Businesses
Route::get('businesses', [BusinessController::class, 'businesses'])->name('businesses');

Route::get('redirect_to/{product_id}', [HomeController::class, 'redirect_to'])->name('redirect_to');