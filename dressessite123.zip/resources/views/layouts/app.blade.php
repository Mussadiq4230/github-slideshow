<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>
  @if(isset($page_title)) 
    {{$page_title}} 
  @else  
    Dress Ads | Ads Network 
  @endif
</title>
<meta name="description" content="Find all sorts of dresses from famous brands and stores from all over the internet.">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="{{asset('js/bootstrap/css/bootstrap.min.css')}}" />

<script type="text/javascript" src="{{asset('js/jquery-2.1.1.min.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome/css/font-awesome.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('css/stylesheet.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('css/owl.carousel.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('css/owl.transitions.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('css/responsive.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('css/stylesheet-skin4.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('revolution/css/settings.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('revolution/css/layers.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('revolution/css/navigation.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('js/swipebox/src/css/swipebox.min.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />
<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900' type='text/css'>
<style type="text/css">
  .border_bottom{
        border-bottom: 2px solid #ddd;
        margin-bottom: 20px;
  }
  #column-left > h5{
    font-weight: bold;
  }
  .more{
    color:#795548;
    cursor:pointer;
    text-align: center;
   
    padding: 10px;
    font-weight: bold;
  }
  .less{
    padding: 10px;
    color:#795548;
    cursor:pointer;
    text-align: center;
    font-weight: bold;
  }
  .attributes{
    background: #f7f7f7;
    
    margin-left: 3px;
    margin-right: 3px;
  }
  .pl0{
    padding-left: 0px;
  }
  .pr0{
    padding-right: 0px;
  }
  .pl1{
    padding-left: 1px;
  }
  .pr1{
    padding-right: 1px;
  }
  .pl2{
    padding-left: 2px;
  }
  .pr2{
    padding-right: 2px;
  }

 #share-div .fa {
  padding: 10px;
    font-size: 25px;
    width: 49px;
    text-align: center;
    text-decoration: none;
    margin: 5px 2px;
}

#share-div .fa:hover {
    opacity: 0.7;
}

#share-div .fa-facebook {
  background: #3B5998;
  color: white;
}

#share-div .fa-twitter {
  background: #55ACEE;
  color: white;
}

#share-div .fa-mail {
  background: #dd4b39;
  color: white;
}

#share-div .fa-tumblr {
  background: #2c4762;
  color: white;
}
#share-div .fa-linkedin {
  background: #007bb5;
  color: white;
}

#share-div .fa-instagram {
  background: #125688;
  color: white;
}

#share-div .fa-pinterest {
  background: #cb2027;
  color: white;
}
</style>
</head>
<body>
<div class="wrapper-wide">
  <div id="header" class="style2">
    <!-- Top Bar Start-->
    <nav id="top" class="htop">
      <div class="container">
        <div class="row"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
          <div class="pull-left flip left-top">
            <div class="links" style="border: 0">
              <ul>
                <li class="mobile" style="text-transform: none;border:0;"> Amazing Dress Deals! Up to 75% Off All Dresses with code: DRESSESADS</li>
                
     
              </ul>
            </div>
          
          </div>
          <div id="top-links" class="nav pull-right flip">
            <ul>
              <li><a href="#">Login</a></li>
              <li><a href="#">Register</a></li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <!-- Top Bar End-->
    <!-- Header Start-->
    <header class="header-row">
      <div class="container">
        <div class="table-container">
           <!-- Logo Start -->
          <div class="col-table-cell col-lg-4 col-md-6 col-sm-12 col-xs-12">
            <div id="logo" style="text-align: left!important"><a href="{{route('home')}}"><img class="img-responsive" src="{{asset('image/logo.png')}}" title="Dress Ads" alt="Dress Ads" /></a></div>
          </div>
          <!-- Logo End -->
          <!-- Mini Cart Start-->
          <div class="col-table-cell col-lg-4 col-md-3 col-sm-12 col-xs-12 inner">
            
          </div>
          <!-- Mini Cart End-->
          
          <!-- Search Start-->
          <div class="col-table-cell col-lg-4 col-md-3 col-sm-12 col-xs-12 inner">
         <div id="search" class="input-group" style="width: 75% !important">
                <input id="filter_name" type="text" name="search" value="" placeholder="Search" class="form-control input-lg" />
                <button type="button" class="button-search"><i class="fa fa-search"></i></button>

              </div>
               <button type="button" class="btn btn-primary" style="font-size:11px;padding:3px;height: 35px;width:25% !important;" data-loading-text="Loading..." data-toggle="modal" data-target="#myModal">Advance Search</button>
         

              <!-- Modal Starts Adv Search -->
              <div class="modal fade" id="myModal" role="document">
                <div class="modal-dialog modal-lg">
                
                  <!-- Modal content-->
                  <div class="modal-content">
                   
                    <div class="modal-body">
                      <h4>Advance Search</h4>
                      <hr/>
                      <div class="row">
                  
                        <div class="col-lg-3">
                          <div class="form-group">
                            <label class="control-label" for="parent_cateogry" style="font-weight: bold">Please Select</label>
                            <select name="parent_category" id="parent_category" class="form-control search-select" required="">
                             <!--  @foreach($pc_categories as $p_category)
                                <option value="{{$p_category->id}}">{{$p_category->parent_category_name}}</option>
                              @endforeach -->
                               <option value="1">Women</option>
                              <option value="2">Men</option>
                              <option value="3">Kids</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3" id="sub_category_div">
                          <div class="form-group">
                            <label class="control-label " for="parent_cateogry" style="font-weight: bold">Please Select</label>
                            <select name="parent_category" id="parent_category" class="form-control search-select" required="">
                                <option value="">Select</option>
                              <option value="5">Baby</option>
                              <option value="6">Boy</option>
                              <option value="7">Girl</option>

                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3" id="category_div">
                          <div class="form-group">
                            <label class="control-label" for="category_name" style="font-weight: bold">Select Category</label>
                            <select name="category_name" id="category_name" class="search-select form-control" required="">
                              <option value="">Select</option>
                              @foreach($categories as $category)
                                <option value="{{$category->category_name}}">{{$category->category_name}}</option>
                              @endforeach

                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3" id="store_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold">Select Store</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              <option value="all">All Stores</option>
                              @foreach($stores as $store)
                                <option value="{{$store->id}}">{{$store->store_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                          <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold">Select Brand</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              <option value="all">All Brands</option>
                              @foreach($brands as $brand)
                                <option value="{{$brand->id}}">{{$brand->store_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                        <div class="row" id="price_div" style="margin-left:2px">
                        <div class="col-md-12" >
                               <label class="control-label" for="" style="font-weight: bold">By Price</label>
                        </div>

                        <div class="col-lg-7">
                       
                            <div  class="form-inline">
                             
                         
                                <div class="form-group   input-group" >
                              <label class="control-label input-group-addon" for="min_price">$</label>
                              <input type="number" class="form-control" min="0" name="min_price" placeholder="Min" >
                              </div>
                              <span>-</span>

                       
                                <div class="form-group  input-group" >
                              <label class="control-label input-group-addon" for="max_price">$</label>
                              <input type="number" class="form-control" min="0" name="max_price" placeholder="Max" >
                        
                          </div>
                          
                            </div>
                                <br/>  
                        </div>
                      <div class="col-lg-3" >
                          <div class="container" style="padding-left: 2rem">
                            <label class="radio">
                              <input type="radio" class="radio" name="price_range" value="0-100"> <span>$0 - $100</span>
                             </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="100-200"> <span>$100 - $200</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="200-500" /> <span>$200 - $500</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="500-1000"/> <span>$500 - $1000</span>
                              </label>
                              <label class="radio">
                                <input type="radio" class="radio" name="price_range" value="1000+"> <span>$1000+</span>
                              </label>
                          </div>
                         </div>
                             <div class="col-lg-2" ></div>
                        </div>

                        <div class="col-lg-12" id="color_div">
                          <div class="form-group">
                            <label class="control-label" for="colors" style="font-weight: bold">By Color</label>
                              <br/>
                              <div id='colors'>
                                <div class="row">
                                  @foreach($colors as $color)
                                    <div class="col-md-2" style="min-width: max-content">
                                      <input type="checkbox" name="selected_colors[]" value={{$color->id}} /> <span style="margin-left:2px">  {{$color->color_name}} </span>
                                    </div>
                                  @endforeach
                                </div>
                              </div>
                          </div>
                        </div>
                     
                        <div class="col-lg-12" id="size_div">
                          <div class="form-group">
                            <label class="control-label" for="store_id" style="font-weight: bold">By Size</label>
                              <br/>
                              <div id='sizes'>
                                <div class="row">
                                  @foreach($sizes as $size)
                                    <div class="col-md-2">
                                      <input type="checkbox" name="selected_sizes[]" value={{$size->id}} /> <span style="margin-left:2px">  {{$size->size_name}} </span>
                                    </div>
                                  @endforeach
                                </div>
                              </div>
                          </div>
                        </div>
                           <div class="col-lg-12" id="color_div">
                          <div class="form-group">
                            <label class="control-label" for="colors" style="font-weight: bold">Special Offers</label>
                              <br/>
                              <div id='colors'>
                                <div class="row">
                                
                                  @foreach($offer_types as $offer_type)
                                  <?php 
                                  $offer_type  = (object) $offer_type; ?>
                                    <div class="col-md-2" style="min-width: max-content">
                                      <input type="checkbox" name="selected_offer_types[]" value={{$offer_type->id}} /> <span style="margin-left:2px">  {{$offer_type->offer_type_name}} </span>
                                    </div>
                                  @endforeach
                                </div>
                              </div>
                          </div>
                        </div>

                       <div class="col-lg-12">
                              <hr />
                        </div>
                        
                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold">Dress  Length</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($dress_lengths as $length)
                                <option value="{{$length->id}}">{{$length->dress_length_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                            <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold">Dress Style</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($dress_styles as $style)
                                <option value="{{$style->id}}">{{$style->dress_style_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                            <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Material</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($materials as $material)
                                <option value="{{$material->id}}">{{$material->material_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                            <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Pattern</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($patterns as $pattern)
                                <option value="{{$pattern->id}}">{{$pattern->pattern_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                           <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Neckline</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($necklines as $neckline)
                                <option value="{{$neckline->id}}">{{$neckline->neckline_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                           <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Sleeve Type</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($sleeve_types as $sleeve_type)
                                <option value="{{$sleeve_type->id}}">{{$sleeve_type->sleeve_type_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                           <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Sleeve Length</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($sleeve_lengths as $sleeve_length)
                                <option value="{{$sleeve_length->id}}">{{$sleeve_length->sleeve_length_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Fit Type</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($fit_types as $fit_type)
                                <option value="{{$fit_type->id}}">{{$fit_type->fit_type_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-12">
                              <hr />
                        </div>

                          <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold">Closure</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($closures as $closure)
                                <option value="{{$closure->id}}">{{$closure->closure_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Character</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($characters as $character)
                                <option value="{{$character->id}}">{{$character->character_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Theme</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($themes as $theme)
                                <option value="{{$theme->id}}">{{$theme->theme_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Features</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($features as $feature)
                                <option value="{{$feature->id}}">{{$feature->feature_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Fabric Type</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($fabric_types as $fabric_type)
                                <option value="{{$fabric_type->id}}">{{$fabric_type->fabric_type_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Embellishment</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($embellishments as $embellishment)
                                <option value="{{$embellishment->id}}">{{$embellishment->embellishment_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Garment Care</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($garment_cares as $garment_care)
                                <option value="{{$garment_care->id}}">{{$garment_care->garment_care_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-3" id="brand_div">
                          <div class="form-group ">
                            <label class="control-label " for="store_id" style="font-weight: bold"> Occasion</label>
                            <select name="store_id" id="store_id" class=" search-select form-control" required="" >
                              @foreach($occasions as $occasion)
                                <option value="{{$occasion->id}}">{{$occasion->occasion_name}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-12">
                              <hr />
                        </div>
                      
                       <div class="col-lg-12">
                            <div class="form-group">
                              <label class="control-label" style="font-weight: bold">Season</label>
                              <div id="input-option218">
                                @foreach($seasons as $season)
                                <label class="checkbox-inline">
                                  <input type="checkbox" value="{{$season->id}}" name="seasons[]">
                                  {{$season->season_name}} </label>
                              
                                @endforeach
                              </div>
                            </div>
                        </div>

                       

                        <div class="col-lg-5">
                            <div class="form-group">
                              <label class="control-label" style="font-weight: bold">Climate Pledge Friendly</label>
                              <div id="input-option218">
                                <label class="">
                                  <input type="radio" value="Yes" name="">
                                  Yes </label>
                                <label class="" style="margin-left: 2rem">
                                  <input type="radio" value="No" name="">
                                 No </label>
                               
                              </div>
                            </div>
                        </div>
                           <div class="col-lg-7">
                            <div class="form-group">
                              <label class="control-label" style="font-weight: bold">Show Only</label>
                              <div id="input-option218">
                                @foreach($show_only as $only)
                                <label class="checkbox-inline">
                                  <input type="checkbox" value="{{$only}}" name="show_only[]">
                                  {{$only}} </label>
                              
                                @endforeach
                              </div>
                            </div>
                        </div>
                      </div>
                 
                    </div>
                        <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="hideModal()">Close</button>
                     <button type="submit" class="btn btn-primary" onclick="window.location.href='/products/women'">Search</button>
                  </div>
                  </div>
                 
                </div>
              </div>
          </div>
          <!-- Search End-->
        </div>
      </div>
    </header>
    <!-- Header End-->
    <!-- Main Menu Start-->
    <nav id="menu" class="navbar center">
      <div class="navbar-header"> <span class="visible-xs visible-sm"> Menu <b></b></span></div>
      <div class="container">
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a class="home_link" title="Home" href="{{route('home')}}">Home</a></li>

                 @foreach($pc_categories as $pc_category)
                 
                
                @if($pc_category->parent_category_name == "Kids")
                  <li class="dropdown wrap_custom_block hidden-sm hidden-xs"><a href="#" >{{$pc_category->parent_category_name}}</a>
                    <div class="dropdown-menu custom_block">
                      <ul>
                        <li>
                          <table>
                            <tbody>
                              <tr>
                              
                                <td>
                                  <a href="{{route('shop.categoryProdcuts','baby')}}">
                                    <img alt="" title="Baby" src="{{asset('image/baby.jpg')}}">
                                  </a>
                                </td>
                                <td>
                                  <a href="{{route('shop.categoryProdcuts','girl')}}">
                                    <img alt="" title="Girl" src="{{asset('image/girls.jpg')}}">
                                  </a>
                                </td>
                                <td>
                                  <a href="{{route('shop.categoryProdcuts','boy')}}">
                                    <img alt="" title="Boy" src="{{asset('image/boys.jpg')}}">
                                  </a>
                                </td>
                              </tr>
                             
                             
                               <tr>
                                 @foreach($pc_category->sub_parent_categories as $subparent)
                                  @if($subparent->parent_category_name !="Toodler")
                                   
                                    <td>
                                       @foreach($subparent->our_categories as $our_cat)
                                        <a href="{{route('shop.categoryProdcuts1', [$subparent->parent_category_slug,  $our_cat->category_slug  ])}}" class="btn btn-primary">{{$our_cat->category_name}}</a>
                                       @endforeach
                                    </td>
                              
                                  @endif
                                @endforeach
                              
                              </tr>
                            
                            </tbody>
                          </table>
                        </li>
                      </ul>
                    </div>
                  </li>
                @else
                <li class="dropdown"><a href="{{route('shop.categoryProdcuts',$pc_category->parent_category_slug)}}">{{$pc_category->parent_category_name}}
                </a>
                  <div class="dropdown-menu" >
                      
                      @if($pc_category->our_categories && !empty($pc_category->our_categories))
                      
                        <?php 
                       
                        $count_index = 0;
                      
                         $max_count = count($pc_category->our_categories)/3;
                         $cats1 = array_slice($pc_category->our_categories,$count_index, $max_count);
                         
                         $count_index = $max_count;
                         $max_count = $max_count;
                          $cats2 = array_slice($pc_category->our_categories,$count_index, $max_count);

                           $count_index = count($cats1)+count($cats2);
                         $max_count = count($pc_category->our_categories);
                          $cats3 = array_slice($pc_category->our_categories,$count_index, $max_count);
                       
                         ?>
                           
                         <ul>
                         @foreach($cats1 as $category)
                    
                          
                          <li><a href="{{route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug])}}">{{$category->category_name}}</a></li>
                        @endforeach
                        </ul>
                         <ul>
                         @foreach($cats2 as $category)
                         
                          <li><a href="{{route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug  ])}}">{{$category->category_name}}</a></li>
                        @endforeach
                        </ul>
                        <ul>
                        @foreach($cats3 as $category)
                         
                          <li><a href="{{route('shop.categoryProdcuts1', ['parent_category_slug'=>$pc_category->parent_category_slug,  'category_slug'=>$category->category_slug  ])}}">{{$category->category_name}}</a></li>
                        @endforeach
                        </ul>
                     
                    @endif
                  </div>
                </li>
                @endif
              @endforeach
             
              <li class="contact-link">
                <a href="{{route('shop.offerProducts','today-sale')}}">Today Sales</a>
              </li>

              <li class="contact-link">
                <a href="{{route('shop.offerProducts','new-arrival')}}" >New Arrivals</a>
              </li>
           
              <li class="menu_brands dropdown">
                <a href="{{route('brands')}}">Brands</a>
                <div class="dropdown-menu">
                      
                    <?php 
                    $brands_count = 0;
                    ?>
                    <div class="row" style="margin-left: 2rem">
                    @foreach($brands as $brand)
                    <?php 
                    $brands_count++;
                    if($brands_count>10){
                      break;
                    }
                    ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6"><a href="/shop/{{$brand->store_slug}}"><img src="/logos/<?php echo $brand->store_logo; ?>" class="logo" height="40" width="50" style="object-fit: scale-down;width:-webkit-fill-available;" title="{{$brand->store_name}}" alt="{{$brand->store_name}}" /></a><a href="/shop/{{$brand->store_slug}}">{{$brand->store_name}}</a></div>

                  @endforeach
                  </div>
                  <p>
                   <a style="margin-left: 2rem;padding-bottom:10px;color: lightgrey" href="{{route('brands')}}" class="">More Brands</a>
                 </p> 
                </div>
              </li>

              <li class="menu_brands dropdown"><a href="{{route('online_stores')}}">Online Stores</a>
                <div class="dropdown-menu">                      
                  <?php 
                  $store_count = 0;
                  ?>
                  <div class="row" style="margin-left: 2rem">
                  @foreach($stores as $store)
                  <?php 
                  $store_count++;
                  if($store_count>10){
                    break;
                  }
                  ?>
                  <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6">
                    <a href="/shop/{{$store->store_slug}}">
                      <img src="/logos/<?php echo $store->store_logo; ?>" height="40" width="50" style="object-fit: scale-down;width:-webkit-fill-available;"  class="logo" title="{{$store->store_name}}" alt="{{$store->store_name}}" />
                    </a>
                    <a href="/shop/{{$store->store_slug}}">{{$store->store_name}}</a>
                  </div>
                  @endforeach
                  </div>
                  <p>
                   <a style="padding-bottom:10px;margin-left: 2rem;color: lightgrey" href="{{route('online_stores')}}" class="">More Online Stores</a>
                     
                  </p>
                </div>
              </li>
             
              <li class="dropdown">
                <a href="#">Special Offers
                </a>
                <div class="dropdown-menu" >
              
                  <?php                       
                  $count_index = 0;
                  $max_count = count($offer_types)/2;
                  $cats1 = array_slice($offer_types,$count_index, $max_count);
                  $cats2 = array_slice($offer_types,count($cats1), count($offer_types));       
                  ?>
                  <ul>
                    @foreach($cats1 as $offer_type)
                      <?php $offer_type = (Object) $offer_type; ?>
                      <li>
                        <a href="{{route('shop.offerProducts',$offer_type->offer_type_slug)}}">{{$offer_type->offer_type_name}}</a>
                      </li>
                    @endforeach
                  </ul>
                 <ul>
                  @foreach($cats2 as $offer_type)
                    <?php $offer_type = (Object) $offer_type; ?>
                    <li>
                      <a href="{{route('shop.offerProducts',$offer_type->offer_type_slug)}}">{{$offer_type->offer_type_name}}</a>
                    </li>
                  @endforeach
                </ul>
              </div>
              </li>
              <li class="contact-link">
                <a href="{{route('businesses')}}" >Businesses</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Main Menu End-->
<input type="hidden" id="prev_url" value="{{$_SERVER['REQUEST_URI']}}" />

     <div class="modal fade" id="modal_product_details" role="document">
     
      <div class="modal-dialog modal-lg">
        
          <!-- Modal content-->
          <div class="modal-content">
          
            
       
      
            <div class="modal-body" id="content-div-product">
              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary"  onClick="hideModal3()">Close</button>
            </div>

          </div>

        </div>

  </div>

  </div>
    @yield('content')
 
  <footer id="footer">
    <div class="fpart-first">
      <div class="container">
        <div class="row">
          <div class="contact col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <h5>About Derss Ads</h5>
            <p> On Dress Ads you can find the latest ads about dresses of vast variety from famous online stores and brands.</p>
            <img alt="" src="{{asset('image/logo.png')}}">
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Information</h5>
            <ul>
              <li><a href="/shop/men">Men</a></li>
                    <li><a href="/shop/women">Women</a></li>
                      <li><a href="/shop/baby">Baby</a></li>
                      <li><a href="/shop/girl">Girls</a></li>
                  <li><a href="/shop/boy">Boys</a></li>
            </ul>
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Deals & Offers</h5>
            <ul>
               <li><a href="/shop/today-sale">Todays Sales</a></li>
                  <li><a href="/shop/new-arrival">New Arrivals</a></li>
                  <li><a href="/shop/promo">Special Offers</a></li>
            </ul>
          </div>
          <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
            <h5>Other</h5>
            <ul>
               <li><a href="{{route('site_map')}}">Site Map</a></li>
               <li><a href="{{route('businesses')}}">Businesses</a></li>
             <li><a href="{{route('brands')}}">Brands</a></li>
                  <li><a href="{{route('online_stores')}}">Online Stores</a></li>
              
            </ul>
          </div>
          <div class="column col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h5>Newsletter</h5>
            <div class="form-group">
            <label class="control-label" for="subscribe">Sign up to receive latest news and updates.</label>
            <input id="signup" type="email" required="" placeholder="Email address" name="email" class="form-control">
            </div>
            <input type="submit" value="Subscribe" class="btn btn-primary">
          </div>
        </div>
      </div>
    </div>
    <div class="fpart-second">
      <div class="container">
        <div id="powered" class="clearfix">
          <div class="powered_text pull-left flip">
            <p>Dress Ads © 2021 | Software Pattern</p>
          </div>
          <div class="social pull-right flip"> <a href="#" target="_blank"> <img data-toggle="tooltip" src="{{asset('image/socialicons/facebook.png')}}" alt="Facebook" title="Facebook"></a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="{{asset('image/socialicons/twitter.png')}}" alt="Twitter" title="Twitter"> </a>  <a href="#" target="_blank"> <img data-toggle="tooltip" src="{{asset('image/socialicons/pinterest.png')}}" alt="Pinterest" title="Pinterest"> </a> <a href="#" target="_blank"> <img data-toggle="tooltip" src="{{asset('image/socialicons/rss.png')}}" alt="RSS" title="RSS"> </a> </div>
        </div>
       
      </div>
    </div>
    <div id="back-top"><a data-toggle="tooltip" title="Back to Top" href="javascript:void(0)" class="backtotop"><i class="fa fa-chevron-up"></i></a></div>
  </footer>
  <!--Footer End-->
</div>
<!-- JS Part Start-->
<script type="text/javascript" src="{{asset('js/bootstrap/js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{asset('revolution/js/jquery.themepunch.tools.min.js?rev=5.0')}}"></script>
<script type="text/javascript" src="{{asset('revolution/js/jquery.themepunch.revolution.min.js?rev=5.0')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.easing-1.3.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.dcjqaccordion.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.elevateZoom-3.0.8.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/swipebox/lib/ios-orientationchange-fix.js')}}"></script>
<script type="text/javascript" src="{{asset('js/swipebox/src/js/jquery.swipebox.min.js')}}"></script>

<script type="text/javascript" src="{{asset('js/custom.js')}}"></script>
<!-- JS Part End-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
<script>  


function share(type, url,title=""){
    
    // var url = "https://www.goodsleephealth.ca/demo//articles/single/115";
    
    if(type== "facebook"){
        window.open('https://www.facebook.com/sharer/sharer.php?u='+url,'facebook-share-dialog',"width=626, height=436")
    }
    if(type== "twitter"){
        // url = "Sleep Disorder Information URL:  https://www.goodsleephealth.ca/demo//articles/single/115";
        window.open('https://twitter.com/intent/tweet?text='+title+" "+url,'twitter-share-dialog',"width=626, height=436")
        
    }
    if(type=="linkedin"){
        
        source = "{{url('')}}";
        window.open('http://www.linkedin.com/shareArticle?mini=true&url='+url+'&title='+title+'&source='+source,'linkedin-share-dialog',"width=626, height=436")
    }
    if(type=="tumblr"){
         // http://www.tumblr.com/share/link?url=%5BURL%5D&amp;name=%5Btitle%5D&amp;description=%5Bcontent%5D     
        window.open('http://www.tumblr.com/share/link?url='+url+'&name='+title,'tumblr-share-dialog',"width=626, height=436")
     }
     if(type=="email"){
        
         window.open('mailto:?subject='+title+'&body= Please check out this: '+title+',  URL:'+url,'email-share-dialog',"width=626, height=436")
    }
}


function redirectProduct(id,is_redirect){
  
  if(is_redirect == "yes"){
    
    Object.assign(document.createElement('a'), {
      target: '_blank',
      href: '/redirect_to/'+id,
    }).click();
  }

   let _token   = $('meta[name="csrf-token"]').attr('content');

          $.ajax({
        url: "{{route('get_product_details_modal_content')}}",
        type:"GET",
        data:{
          _token: _token,  id:id
        },
        success:function(response){
         
          if(response && response !="") {
     
            $("#content-div-product").html(response);
            $("#modal_product_details").modal('show');
          }
        },
       });
}
jQuery(document).ready(function() {  

$("#zoom_01").elevateZoom({
  gallery:'gallery_01',
  cursor: 'pointer',
  galleryActiveClass: 'active',
  imageCrossfade: true,
  zoomWindowFadeIn: 500,
  zoomWindowFadeOut: 500,
  lensFadeIn: 500,
  lensFadeOut: 500,
  loadingIcon: 'image/progress.gif'
  }); 
//////pass the images to swipebox
$("#zoom_01").bind("click", function(e) {
  var ez =   $('#zoom_01').data('elevateZoom');
  $.swipebox(ez.getGalleryList());
  return false;
});

   jQuery("#slider1").revolution({
      sliderType:"standard",
      sliderLayout:"fullwidth",
      delay:9000,
      navigation: {
      onHoverStop: "off",
          arrows:{enable:true},
      touch: {
          touchenabled: "on",
          swipe_threshold: 75,
          swipe_min_touches: 1,
          swipe_direction: "horizontal",
          drag_block_vertical: false
      },
      bullets: {
          enable: true,
          hide_onmobile: true,
          style: "hermes",
          hide_onleave: false,
          direction: "horizontal",
          h_align: "center",
          v_align: "bottom",
          h_offset: 20,
          v_offset: 20,
          space: 5,
          tmp: ''
      },
      },
    
                
     gridwidth:1230,
      gridheight:480
    });   


         $(".search-select").selectize({
          sortField: 'text'
      });
}); 
</script>

</body>
</html>

<script type="text/javascript">


      @if(isset($selected) && isset($selected_sub1))
    
        @if(ucfirst($selected) == "Girl" || ucfirst($selected_sub1) == "Girl" || ucfirst($selected_sub1) == "Boy" || ucfirst($selected) == "Boy" || ucfirst($selected) == "Baby" || ucfirst($selected_sub1) == "Baby")
         $("#kids").show();
        @endif
       $("#<?=Str::slug($selected_sub1)?>").show();
       $("#<?=Str::slug($selected)?>").show();
       
       @elseif(isset($selected) && !isset($selected_sub1))
    
        @if(ucfirst($selected) == "Girl"   || ucfirst($selected) == "Boy" || ucfirst($selected) == "Baby")
         $("#kids").show();
        @endif
       $("#<?=Str::slug($selected)?>").show();
     
      @elseif(isset($selected_sub1) &&  !isset($selected))
    
        @if(ucfirst($selected_sub1) == "Girl" || ucfirst($selected_sub1) == "Boy" ||  ucfirst($selected) == "Baby" )
         $("#kids").show();
        @endif
       $("#<?=Str::slug($selected_sub1)?>").show();
       
      @endif
     
     
//  $("#category_div").hide();
  //$("#price_div").hide();
  $("#sub_category_div").hide();
  //$("#color_div").hide();
  //$("#store_div").hide();
  //$("#size_div").hide();
  //$("#brand_div").hide();
    
  
   function hideModal(){
      $("#myModal").modal('hide');
    }

   function hideModal3(){
      $("#modal_product_details").modal('hide');
    }

    $("#parent_category").change(function(event){


      if(event.target.value == "3"){

        $("#sub_category_div").show();
      }else{
        $("#sub_category_div").hide();
      }

      // let parent_category = $("#parent_category").val();
  
      // let _token   = $('meta[name="csrf-token"]').attr('content');

      // $.ajax({
      //   url: "{{route('get_our_categories')}}",
      //   type:"POST",
      //   data:{
      //     parent_category:parent_category,
         
      //     _token: _token
      //   },
      //   success:function(response){
          
      //     if(response && response !="") {
      //       $("#category_name").html(response);
      //     }
      //   },
      //  });
  }
  );

    $("#store_id").change(function(event){

      // event.preventDefault();
      // let store_id = $("#store_id").val();
      // let _token = $("meta[name='csrf-token']").attr('content');

      // $.ajax({
      //   url:"{{route('get_colors')}}",
      //   type:"post",
      //   data:{
      //     store_id : store_id,
      //     _token : _token
      //   },
      //   success:function(response){
      //     if(response && response !="NOCOLOR"){
      //       $("#colors").html(response);
      //     }else if(response && response =="NOCOLOR"){
      //       $("#colors").html("Colors not available");
      //     }
      //   }

      // });

      // $.ajax({
      //   url:"{{route('get_sizes')}}",
      //   type:"post",
      //   data:{
      //     store_id : store_id,
      //     _token : _token
      //   },
      //   success:function(response){
      //     if(response && response !="NOSIZE"){
      //       $("#sizes").html(response);
      //     }else if(response && response =="NOSIZE"){
      //       $("#sizes").html("Sizes not available");
      //     }
      //   }
        
      // });
    });




</script>
