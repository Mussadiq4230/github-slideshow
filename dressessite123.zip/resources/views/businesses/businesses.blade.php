@extends('layouts.app')

@section('content')

	<div id="container">

    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <li><a href="{{route('businesses')}}">Businesses</a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!--Middle Part Start-->

        <div id="content" class="col-sm-9">
        <h1 class="title">Find Businesses Near You</h1>

          <div class="product-filter" style="padding: 14px 14px;">
            <div class="row">
              <div class="col-md-4 col-sm-5">
                <input type="text" placeholder="What? i.e. Formal Dresses" class="form-control" style="height: 34px;">
              </div>
          
             
               <div class="col-md-2 col-sm-2 ">
                <select id="input-sort" class="form-control col-sm-3 search-select" style="height: 34px; ">
                  <option value="" selected="selected">State</option>
                  @foreach($states as $state)

                  <option value="{{$state->state}}">{{$state->state}}</option>
                  @endforeach
                </select>
              </div>
               <div class="col-md-3 col-sm-2 ">
                <select id="input-sort" class="form-control col-sm-3 search-select" style="height: 34px;">
                  <option value="" selected="selected">City</option>
                  @foreach($cities as $city)

                  <option value="{{$city->city}}">{{$city->city}}</option>
                  @endforeach
                </select>
              </div>
              <div class="col-sm-1 text-left">
                <a class="btn btn-primary" href="{{route('businesses')}}" style="height: 34px;font-size: 15px;">
                  <i class="fa fa-search"></i>
                </a>
              </div>


            </div>
          </div>
       
         <div class="row products-category" >

          @foreach($businesses as $business)
          
           
              <div class="product-layout product-list col-xs-12" >
                <div class="product-thumb">
             <!--      <div class="image"><a href="https://www.nastygal.com//get-some-sunflower-floral-mini-dress/AGG44937.html" target="blank"><img src="//media.nastygal.com/i/nastygal/agg44937_black_xl?$product_image_category_page_horizontal_filters_desktop$" alt=" Strategies for Acquiring Your Own Laptop " title=" Strategies for Acquiring Your Own Laptop " class="img-responsive"></a></div> -->
                  <div>
                    <div class="caption">
                      <h4><a href="" target="blank"> {{$business->name}}</a></h4>

                      <p class="description">
                        {{$business->street_address}} , {{$business->city}} {{$business->zip_code}}, {{$business->state}}, {{$business->country}}
                      </p>

                      <p class="description">{{$business->name}} is well known for specializing in formal and casual wear. Casa Orquidea proudly carries a wide variety of..<a href="#"><b>Read more</b></a> </p>
                      @if($business->categories !="") 
                            <p> <b><a href="#">{{$business->categories}}</a></b></p>
                          @endif
                          @if($business->email !="") 
                            <p><b>Email</b>: {{$business->email}}</p> 
                          @endif
                          @if($business->phone !="") 
                            <p> <b>Phone:</b> {{$business->phone}} </p>
                          @endif
                          @if($business->website !="") 
                            <p> <b>Website:</b><a href="{{$business->website}}">{{$business->website}}</a></p>
                          @endif
                          @if($business->years_in_business !="") 
                            <p> <b>Years in Business:</b> <span class="badge badge-primary">
                              {{$business->years_in_business}}
                            </span></p>
                          @endif
                        
                      
                    </div>
                    <div class="button-group">
                      <button class="btn-primary" type="button" onclick="window.open('#')"><span>View Details</span></button>
                      <div class="add-to-links">
                        <button type="button" data-toggle="tooltip" title="" onclick="" data-original-title="Add to wishlist"><i class="fa fa-heart"></i></button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

          @endforeach

            </div>
            <div class="row">
            <div class="col-sm-6 text-left">
             {{$businesses && $businesses->total() >0 ? $businesses->links('pagination::bootstrap-4') : ""}}
            </div>
         
              <div class="col-sm-6 text-right">Showing {{count($businesses->items())}} out of {{$businesses->total()}} items </div>
 
          </div>
               
        </div>
          <div id="content" class="col-sm-3" >
            <img src="{{asset('image/add1.jpg')}}" class="col-md-12" style="margin-top: 20%">
            <br>
            <img src="{{asset('image/add2.jpg')}}" class="col-md-12" style="margin-top: 20%"></div>
         </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>

@endsection