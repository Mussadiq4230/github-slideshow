

<?php $__env->startSection('content'); ?>

<div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e($key); ?>"><?php echo e($value); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <!-- Breadcrumb End-->
      <form action="<?php echo e($_SERVER['PATH_INFO']); ?>" action="get" id="main_form"> 
      <div class="row">
        <!--Left Part Start -->
      <aside id="column-left" class="col-sm-3 hidden-xs">
                     <h5 >Categories <a href="<?php echo e($_SERVER['PATH_INFO']); ?>" style="float: right">Clear All</a></h5>
            <div class="box-category border_bottom" >
              <ul id="cat_accordion">
                <li><a href="/shop<?php echo e($store_filter); ?>" style="font-weight: <?php echo "All Categories" == $selected ? "bold": "normal"; ?>">All Categories</a></li>
                <?php $__currentLoopData = $pc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li 
                
                ><a href="<?php if($cat->parent_category_name == 'Kids') { echo '#'; }else{ echo '/shop/'.$cat->parent_category_slug; }?><?php echo e($store_filter); ?>"
                    style="font-weight: <?php echo $cat->parent_category_name == $selected || $cat->parent_category_name == ucfirst($selected_sub1) ? "bold": "normal"; ?>"
                  ><?php echo e($cat->parent_category_name); ?></a> <span class="down"></span>
                  <ul id="<?php echo e($cat->parent_category_slug); ?>" class="<?php if($cat->parent_category_name !='Kids') {echo 'term-list';} ?>">
                   <?php if($cat->sub_parent_categories): ?>

                     <?php $__currentLoopData = $cat->sub_parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_parent_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <li ><a  href="/shop/<?php echo e($sub_parent_category->parent_category_slug); ?><?php echo e($store_filter); ?>"
                      style="font-weight: <?php echo $sub_parent_category->parent_category_name == $selected || $sub_parent_category->parent_category_name == ucfirst($selected_sub1) ? "bold": "normal"; ?>"
                      >
                       <?php echo e($sub_parent_category->parent_category_name); ?>

                     </a>
                      <span class="down" ></span>
                      <ul id="<?php echo e($sub_parent_category->parent_category_slug); ?>" class="term-list">
                        <?php $__currentLoopData = $sub_parent_category->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="term-item" >
                            <a 
                            style="font-weight: <?php echo $category->category_name == $selected ? "bold": "normal"; ?>"
                            href="/shop/<?php echo e($sub_parent_category->parent_category_slug); ?>/<?php echo e($category->category_slug); ?><?php echo e($store_filter); ?>"><?php echo e($category->category_name); ?></a> 
                            <?php if(!empty($category->sub_categories)): ?><span class="down"></span> <?php endif; ?>
                            <ul id="<?php echo e($category->category_slug); ?>">
                              <?php if(isset($category->sub_categories)): ?>
                                <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><a href="/shop/<?php echo e($sub_parent_category->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>/<?php echo e($sub_cat->category_slug); ?><?php echo e($store_filter); ?>"><?php echo e($sub_cat->category_name); ?> </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                            </ul>
                          </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                     </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php else: ?>
                     <?php $__currentLoopData = $cat->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="term-item"><a
                            style="font-weight: <?php echo $category->category_name == $selected ? "bold": "normal"; ?>"
                         href="/shop/<?php echo e($cat->parent_category_slug); ?>/<?php echo e($category->category_slug); ?><?php echo e($store_filter); ?>"><?php echo e($category->category_name); ?></a> 
                          <?php if(!empty($category->sub_categories)): ?><span class="down"></span> <?php endif; ?>
                          <ul>
                            <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a 
                              href="/shop/<?php echo e($cat->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>/<?php echo e($sub_cat->category_slug); ?><?php echo e($store_filter); ?>"><?php echo e($sub_cat->category_name); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                  
                  </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
              </ul>
            </div>


            <?php if(isset($other_counts['brand'])): ?>
              <h5 >Brand  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
              <div class="side-item border_bottom term-list">

                <?php $i=0; ?>

                <?php $__currentLoopData = $other_counts['brand']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                  <?php if($i >5): ?>
                    <?php
                      // break; 
                      ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox term-item" >
                      <label>
                        <input
                        <?php if((isset($request_data->store) && in_array($brand->count_id, $request_data->store)) || (isset($request_data->brand)  &&  in_array($brand->count_id, $request_data->brand))){?> checked='checked' <?php }?>  
                         type="checkbox" name="brand[]" name="brand_id"  onchange="submitForm()"  id="checkboxSuccess" value="<?php echo e($brand->count_id); ?>">
                        <?php echo e($brand->count_name); ?> (<?php echo e($brand->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>

            <?php if(isset($other_counts['store'])): ?>
              <h5 >Online Stores  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
              <div class="side-item border_bottom term-list">
                <?php $i=0; ?>
                <?php $__currentLoopData = $other_counts['store']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php 
                     // break; 
                     ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox term-item">
                    <label> 
                      <input
                       <?php if((isset($request_data->store) && in_array($store->count_id, $request_data->store)) || (isset($request_data->brand)  &&  in_array($store->count_id, $request_data->brand))){ ?> checked='checked' <?php }?>  
                       type="checkbox" name="store[]" name="store_id" onchange="submitForm()" id="checkboxSuccess" value="<?php echo e($store->count_id); ?>">
                      <?php echo e($store->count_name); ?> (<?php echo e($store->total_count); ?>) </label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>

            <h5>By Price </h5>
            <div class="side-item border_bottom">
              <div  class="form-inline row" style="margin-left: 1px">

                <div class="form-group   input-group col-md-4" >
                 
                  <input type="number" id="min_price"  value="<?php echo e(isset($request_data->min_price) && $request_data->min_price ? $request_data->min_price: ''); ?>"  class="form-control" min="0" name="min_price" placeholder="Min" >
                </div>
                <span>-</span>
                <div class="form-group  input-group col-md-4"  >
                  <input type="number"  value="<?php echo e(isset($request_data->max_price) && $request_data->max_price ? $request_data->max_price: ''); ?>" id="max_price"  class="form-control" min="0" name="max_price" placeholder="Max" >
                </div>
                <div class="form-group col-md-2" style="float: right;margin-right: 2.5rem;">
                    <button type="button" class=" btn btn-xs btn-info" onclick="submitForm('price')" style="height: 33px"><i class="fa fa-search"></i></button>
                </div>
              </div>
               <div class="container" style="padding-left: 2rem">
                <label class="radio">
                  <input type="radio" class="radio" 
                  <?php if(isset($request_data->price_range) && $request_data->price_range == '0-100'){ ?> checked='checked' <?php }?>  
                  onchange="submitForm('price_range')" id="price_range" name="price_range" value="0-100"  > <span>$0 - $100</span>
                 </label>
                  <label class="radio">
                    <input
                    <?php if(isset($request_data->price_range) && $request_data->price_range == '100-200'){ ?> checked='checked' <?php }?>  
                     type="radio" class="radio" onchange="submitForm('price_range')" name="price_range" id="price_range" value="100-200"> <span>$100 - $200</span>
                  </label>
                  <label class="radio">
                    <input
                     <?php if(isset($request_data->price_range) && $request_data->price_range == '200-500'){ ?> checked='checked' <?php }?> 
                     type="radio" class="radio" onchange="submitForm('price_range')" name="price_range" id="price_range" value="200-500" /> <span>$200 - $500</span>
                  </label>
                  <label class="radio">
                    <input
                    <?php if(isset($request_data->price_range) && $request_data->price_range == '500-1000'){ ?> checked='checked' <?php }?> 
                     type="radio" class="radio" onchange="submitForm('price_range')" name="price_range" id="price_range" value="500-1000"/> <span>$500 - $1000</span>
                  </label>
                  <label class="radio">
                    <input
                    <?php if(isset($request_data->price_range) && $request_data->price_range == '1000+'){ ?> checked='checked' <?php }?> 
                     type="radio" class="radio" onchange="submitForm('price_range')" name="price_range" id="price_range" value="1000+"> <span>$1000+</span>
                  </label>
              </div>
            </div>

            <h5>Special Offers <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item  border_bottom">
          
              <?php $__currentLoopData = $other_counts['offer_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge "     title ="<?php echo e($offer_type->count_name); ?>" style="color:inherit;margin-bottom:3px;background:<?php if(isset($request_data->offer_type) && in_array($offer_type->count_id, $request_data->offer_type)){ echo '#9e9e9e'; }else{ echo 'lightgrey'; }?>; ">
                  <input
                   <?php if(isset($request_data->offer_type) && in_array($offer_type->count_id, $request_data->offer_type)){ ?> checked='checked' <?php }?> 
                  type="checkbox" onchange="submitForm()" name="offer_type[]" id="checkboxSuccess" value="<?php echo e($offer_type->count_id); ?>">
                <?php echo e($offer_type->count_name); ?> (<?php echo e($offer_type->total_count); ?>)
              </span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </div>
        <?php if($show_filters): ?>


         <?php 
           if(isset($all_counts['dress_style']) &&  !(isset($all_counts['dress_style'][0])  && count($all_counts['dress_style']) == 1   && $all_counts['dress_style'][0]->count_name == "Unspecified" && $all_counts['dress_style'][0]->total_count <1)){
              ?>

            <h5>Dress Style  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item border_bottom">
              <?php $i=0; ?>
              <?php $__currentLoopData = $all_counts['dress_style']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dstyle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                  <?php  break; ?>
                <?php endif; ?>
                <?php $i++;?>
                <div class="checkbox">
                    <label>
                      <input
                       <?php if(isset($request_data->dress_style) && in_array($dstyle->count_id, $request_data->dress_style)){ ?> checked='checked' <?php }?> 
                       type="checkbox"  onchange="submitForm()" id="checkboxSuccess" name="dress_style[]" value="<?php echo e($dstyle->count_id); ?>">
                      <?php echo e($dstyle->count_name); ?> (<?php echo e($dstyle->total_count); ?>) </label>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

          <?php 

          } ?>

        <?php 
           if(isset($all_counts['dress_length']) && !(isset($all_counts['dress_length'][0]) && count($all_counts['dress_length']) == 1  && $all_counts['dress_length'][0]->count_name == "Unspecified" && $all_counts['dress_length'][0]->total_count <1)){
              ?>


             <h5>Length  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="border_bottom">
              <?php $i=0; ?>
              <?php $__currentLoopData = $all_counts['dress_length']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress_length): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                  <?php  break; ?>
                <?php endif; ?>
                <?php $i++;?>
                <div class="checkbox">
                    <label>
                      <input
                      <?php if(isset($request_data->dress_length) && in_array($dress_length->count_id, $request_data->dress_length)){ ?> checked='checked' <?php }?> 
                       type="checkbox" onchange="submitForm()" name="dress_length[]" id="checkboxSuccess" value="<?php echo e($dress_length->count_id); ?>">
                      <?php echo e($dress_length->count_name); ?> (<?php echo e($dress_length->total_count); ?>) </label>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>

            <?php 
            }
            ?>

             <?php 
           if(isset($all_counts['pattern']) && !(isset($all_counts['pattern'][0]) && count($all_counts['pattern']) == 1  && $all_counts['pattern'][0]->count_name == "Unspecified" && $all_counts['pattern'][0]->total_count <1)){
              ?>

              <h5>Pattern  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
              <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['pattern']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                        <?php if(isset($request_data->pattern) && in_array($pattern->count_id, $request_data->pattern) ){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" id="checkboxSuccess" name="pattern[]" value="<?php echo e($pattern->count_id); ?>">
                        <?php echo e($pattern->count_name); ?> (<?php echo e($pattern->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
            ?>

             <?php 
           if(isset($all_counts['neckline']) && !(isset($all_counts['neckline'][0]) && count($all_counts['neckline']) == 1 &&  $all_counts['neckline'][0]->count_name == "Unspecified" && $all_counts['neckline'][0]->total_count <1)){
              ?>

              <h5>Neckline  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item border_bottom">
              <?php $i=0;?>
              <?php $__currentLoopData = $all_counts['neckline']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $neckline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                  <?php  break; ?>
                <?php endif; ?>
                <?php $i++;?>
                <div class="checkbox">
                    <label>
                      <input
                       <?php if(isset($request_data->neckline) && in_array($neckline->count_id, $request_data->neckline)){ ?> checked='checked' <?php }?> 
                      type="checkbox" onchange="submitForm()" id="checkboxSuccess" name="neckline[]" value="<?php echo e($neckline->count_id); ?>">
                      <?php echo e($neckline->count_name); ?> (<?php echo e($neckline->total_count); ?>) </label>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
            <?php 
            }
            ?>


            <?php 
           if(isset($all_counts['sleeve_type']) && !(isset($all_counts['sleeve_type'][0])  && count($all_counts['sleeve_type']) == 1 && $all_counts['sleeve_type'][0]->count_name == "Unspecified" && $all_counts['sleeve_type'][0]->total_count <1)){
              ?>


              <h5>Sleeve Type  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item border_bottom">
              <?php $i=0;?>
              <?php $__currentLoopData = $all_counts['sleeve_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                  <?php  break; ?>
                <?php endif; ?>
                <?php $i++;?>
                <div class="checkbox">
                    <label>
                      <input
                       <?php if(isset($request_data->sleeve_type) && in_array($sleeve_type->count_id, $request_data->sleeve_type)){ ?> checked='checked' <?php }?> 
                       type="checkbox" onchange="submitForm()" id="checkboxSuccess" name="sleeve_type[]" value="<?php echo e($sleeve_type->count_id); ?>">
                      <?php echo e($sleeve_type->count_name); ?> (<?php echo e($sleeve_type->total_count); ?>) </label>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
            <?php 
            }
            ?>
            
            
            <?php 
           if(isset($all_counts['embellishment']) &&  !(isset($all_counts['embellishment'][0]) && count($all_counts['embellishment']) == 1 &&  $all_counts['embellishment'][0]->count_name == "Unspecified" && $all_counts['embellishment'][0]->total_count <1)){
              ?>

              <h5>Embellishment  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
              <div class="side-item border_bottom">
                <?php  $i=0;?>
                <?php $__currentLoopData = $all_counts['embellishment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embellishment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input 
                          <?php if(isset($request_data->embellishment) && in_array($embellishment->count_id, $request_data->embellishment)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="embellishment[]" id="checkboxSuccess" value="<?php echo e($embellishment->count_id); ?>">
                        <?php echo e($embellishment->count_name); ?> (<?php echo e($embellishment->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              </div>
            <?php 
            }
            ?>
              
            <?php 
            if(isset($all_counts['material']) && !(isset($all_counts['material'][0]) && count($all_counts['material']) == 1 && $all_counts['material'][0]->count_name == "Unspecified" && $all_counts['material'][0]->total_count <1)){
              ?>
                <h5>Material  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['material']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->material) && in_array($material->count_id, $request_data->material)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="material[]" id="checkboxSuccess" value="<?php echo e($material->count_id); ?>">
                        <?php echo e($material->count_name); ?> (<?php echo e($material->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>

            <?php 
            if(isset($all_counts['character']) && !(isset($all_counts['character'][0]) && count($all_counts['character']) == 1 && $all_counts['character'][0]->count_name == "Unspecified" && $all_counts['character'][0]->total_count <1)){
              ?>
                <h5>Character  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['character']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->character) && in_array($character->count_id, $request_data->character)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="character[]" id="checkboxSuccess" value="<?php echo e($character->count_id); ?>">
                        <?php echo e($character->count_name); ?> (<?php echo e($character->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>

          <?php 
            if(isset($all_counts['closure']) && !(isset($all_counts['closure'][0]) && count($all_counts['closure']) == 1 && $all_counts['closure'][0]->count_name == "Unspecified" && $all_counts['closure'][0]->total_count <1)){
              ?>
                <h5>Closure  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['closure']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $closure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->closure) && in_array($closure->count_id, $request_data->closure)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="closure[]" id="checkboxSuccess" value="<?php echo e($closure->count_id); ?>">
                        <?php echo e($closure->count_name); ?> (<?php echo e($closure->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>

           <?php 
            if(isset($all_counts['fabric_type']) && !(isset($all_counts['fabric_type'][0]) && count($all_counts['fabric_type']) == 1 && $all_counts['fabric_type'][0]->count_name == "Unspecified" && $all_counts['fabric_type'][0]->total_count <1)){
              ?>
                <h5>Fabric Type  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['fabric_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->fabric_type) && in_array($fabric_type->count_id, $request_data->fabric_type)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="fabric_type[]" id="checkboxSuccess" value="<?php echo e($fabric_type->count_id); ?>">
                        <?php echo e($fabric_type->count_name); ?> (<?php echo e($fabric_type->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>

             <?php 
            if(isset($all_counts['feature']) && !(isset($all_counts['feature'][0]) && count($all_counts['feature']) == 1 && $all_counts['feature'][0]->count_name == "Unspecified" && $all_counts['feature'][0]->total_count <1)){
              ?>
                <h5>Feature  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['feature']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->feature) && in_array($feature->count_id, $request_data->feature)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="feature[]" id="checkboxSuccess" value="<?php echo e($feature->count_id); ?>">
                        <?php echo e($feature->count_name); ?> (<?php echo e($feature->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>
        
            <?php 
            if(isset($all_counts['fit_type']) && !(isset($all_counts['fit_type'][0]) && count($all_counts['fit_type']) == 1 && $all_counts['fit_type'][0]->count_name == "Unspecified" && $all_counts['fit_type'][0]->total_count <1)){
              ?>
                <h5>Fit Type  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['fit_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->fit_type) && in_array($fit_type->count_id, $request_data->fit_type)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="fit_type[]" id="checkboxSuccess" value="<?php echo e($fit_type->count_id); ?>">
                        <?php echo e($fit_type->count_name); ?> (<?php echo e($fit_type->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>
             <?php 
            if(isset($all_counts['occasion']) && !(isset($all_counts['occasion'][0]) && count($all_counts['occasion']) == 1 && $all_counts['occasion'][0]->count_name == "Unspecified" && $all_counts['occasion'][0]->total_count <1)){
              ?>
                <h5>Occasion  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
                <div class="side-item border_bottom">
                <?php $i=0; ?>
                <?php $__currentLoopData = $all_counts['occasion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <?php if($i >5): ?>
                    <?php  break; ?>
                  <?php endif; ?>
                  <?php $i++;?>
                  <div class="checkbox">
                      <label>
                        <input
                         <?php if(isset($request_data->occasion) && in_array($occasion->count_id, $request_data->occasion)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="occasion[]" id="checkboxSuccess" value="<?php echo e($occasion->count_id); ?>">
                        <?php echo e($occasion->count_name); ?> (<?php echo e($occasion->total_count); ?>) </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            <?php 
            }
          ?>
          <?php endif; ?>

          <?php if(isset($colors)): ?>
             <h5>Colors </h5>     
            <div class="side-item ">
              <?php  $i=0;?>
              <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
                <?php if($i >5): ?>
                  <?php  break; ?>
                <?php endif; ?>
                <?php $i++;?>

                <button type="button" class="btn btn-circle"  title ="<?php echo e($color->color_name); ?>" style="height: 30px; width: 30px;margin-bottom:3px; border:  <?php if(isset($request_data->color)  && in_array($color->id, $request_data->color)){ echo '2px solid black';  }else{ echo '1px solid lightgray'; }?> ;padding: 5px;border-radius: 100%;margin-right:2px;background:<?php echo e($color->color_code); ?>">
              
                    <input
                         <?php if(isset($request_data->color) && in_array($color->id, $request_data->color)){ ?> checked='checked' <?php }?> 
                        type="checkbox" onchange="submitForm()" name="color[]" id="checkboxSuccess" value="<?php echo e($color->id); ?>">
                  </button>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
            <br/>
            <?php endif; ?>

            <?php if(isset($other_counts['size_map'])): ?>
                <h5>Sizes <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item ">
              <?php  $i=0; ?>
              <?php $__currentLoopData = $other_counts['size_map']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                <?php break; ?>
                <?php endif; ?>
                <?php $i++;?> 
                <button type="button" class="btn btn-circle"   title ="<?php echo e($size->count_name); ?>" style="margin-bottom:3px; border:   <?php if(isset($request_data->size) && in_array($size->count_id, $request_data->size)){ echo '2px double black'; }else{ echo '1px solid lightgray'; }?>; margin-right:2px;">
                  <input
                   <?php if(isset($request_data->size) && in_array($size->count_id, $request_data->size)){ ?> checked='checked' <?php }?> 
                  type="checkbox" onchange="submitForm()" name="size[]" id="checkboxSuccess" value="<?php echo e($size->count_id); ?>">
                <?php echo e($size->count_name); ?>

              </button>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>

                     <br/>
          <?php endif; ?>

          <?php if(isset($other_counts['garment_care'])): ?>
                <h5>Garment Care <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item ">
              <?php  $i=0; ?>
              <?php $__currentLoopData = $other_counts['garment_care']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garment_care): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                <?php break; ?>
                <?php endif; ?>
                <?php $i++;?> 
                   <label class="label " style="background: transparent;color:inherit; font-size:12px;font-weight:normal;padding: 10px">
                    <input
                     <?php if(isset($request_data->garment_care) && in_array($garment_care->count_id, $request_data->garment_care)){ ?> checked='checked' <?php }?> 
                    type="checkbox" onchange="submitForm()" name="garment_care[]" id="checkboxSuccess" value="<?php echo e($garment_care->count_id); ?>">
                  <?php echo e($garment_care->count_name); ?>

                  </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
              <br/>
          <?php endif; ?>
            <?php if(isset($other_counts['season'])): ?>
                <h5>Season <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
            <div class="side-item ">
              <?php  $i=0; ?>
              <?php $__currentLoopData = $other_counts['season']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <?php if($i >5): ?>
                <?php break; ?>
                <?php endif; ?>
                <?php $i++;?> 
                  <label class="label " style="background: transparent;color:inherit; font-size:12px;font-weight:normal;padding: 10px">
                    <input
                     <?php if(isset($request_data->season) && in_array($season->count_id, $request_data->season)){ ?> checked='checked' <?php }?> 
                    type="checkbox" onchange="submitForm()" name="season[]" id="checkboxSuccess" value="<?php echo e($season->count_id); ?>">
                    <?php echo e($season->count_name); ?>

                  </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
          <?php endif; ?>
          </aside>
        <!--Left Part End -->
        <!--Middle Part Start-->
        <div id="content" class="col-sm-9">
          <h1 class="title"><?php echo e($selected_store->store_name); ?></h1>
              <?php if($products && $products->total()>0): ?>
       <!--    <h3 class="subtitle">Similar Stores</h3>
      
          <div class="category-list-thumb row">

            <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">  <a href="/online_stores_products/<?php echo e($store->store_slug); ?>">
      <?php   $key = array_search($store->store_name, array_column($other_counts['store']->toArray(), 'count_name'));

      ?>
                            
                <?php echo e($store->store_name); ?>(<?php echo e($other_counts['store']->toArray()[$key]['total_count']); ?>)</a> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div> -->
          <div class="product-filter">
            <div class="row">
              <div class="col-md-4 col-sm-5">
                <div class="btn-group">
                 <!--  <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button> -->
                  <button type="button" id="grid-view" class="btn btn-default" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
                </div>
                <a href="#" id="compare-total">Product Compare (0)</a> </div>
              <div class="col-sm-2 text-right">
                <label class="control-label" for="input-sort">Sort By:</label>
              </div>
                       <div class="col-md-3 col-sm-2 text-right">
                  <select id="input-sort" value="<?php echo e(isset($request_data->sort) ? $request_data->sort :''); ?>" name="sort" onchange="submitForm()" class="form-control col-sm-3">
                    <option value="">Default</option>
                    <option 
                   <?php echo e(isset($request_data->sort) && $request_data->sort == 'name-asc'? 'selected' :''); ?>

                    value="name-asc"
                     >Name (A - Z)</option>
                    <option 
                     <?php echo e(isset($request_data->sort) && $request_data->sort == 'name-desc'? 'selected' :''); ?>

                    value="name-desc"
                    >Name (Z - A)</option>
                    <option 
                    <?php echo e(isset($request_data->sort) && $request_data->sort == 'price-asc'? 'selected' :''); ?>

                    value="price-asc"
                    >Price (Low &gt; High)</option>
                    <option 
                   <?php echo e(isset($request_data->sort) && $request_data->sort == 'price-desc'? 'selected' :''); ?>

                    value="price-desc"
                    >Price (High &gt; Low)</option>
                  </select>
                </div>
                <div class="col-sm-1 text-right">
                  <label class="control-label" for="input-limit">Show:</label>
                </div>
              
                <div class="col-sm-2 text-right">
                  <select id="input-limit"  name="limit" onchange="submitForm()" class="form-control">
                      <option 
                    value="10" 
                   <?php echo e(isset($request_data->limit) && $request_data->limit == 10? 'selected' :''); ?>

                    >10</option>
                    <option 
                    value="20" 
                   <?php echo e(isset($request_data->limit) && $request_data->limit == 20? 'selected' :''); ?>

                    >20</option>
                    <option 
                    <?php echo e(isset($request_data->limit) && $request_data->limit == '25'? 'selected' :''); ?>

                    value="25"
                    >25</option>
                    <option 
                   <?php echo e(isset($request_data->limit) && $request_data->limit == '50'? 'selected' :''); ?>

                    value="50"
                    >50</option>
                    <option 
                    <?php echo e(isset($request_data->limit) && $request_data->limit == '75'? 'selected' :''); ?>

                    value="75"
                    >75</option>
                    <option 
                    <?php echo e(isset($request_data->limit) && $request_data->limit == '100'? 'selected' :''); ?>

                    value="100"
                    >100</option>
                  </select>
                </div>
            </div>
          </div>
          <br />
          <div class="row products-category">
                 <?php 
              $i=1;
              ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php 
               $product_image = "";

               if(strpos($product->image,',')!==false){
                  $product_image = explode(",", $product->image)[0];
               }else{
                  $product_image = $product->image;
               }
               ?>
              <div class="product-layout product-list col-xs-12">
                <div class="product-thumb">
                  <div class="image"><a href="#" onclick="redirectProduct('<?php echo e($product->id); ?>')"><img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" class="img-responsive" /></a></div>
                  <div>

                    <div class="caption">
                      <h4><a href="#" onclick="redirectProduct('<?php echo e($product->id); ?>')"><?php echo e($product->name); ?></a></h4>
                            <?php if($product->sale_price && $product->sale_price !=""): ?>
                           <p class="price"> <span class="price-new">$<?php echo e($product->sale_price); ?></span> <span class="price-old">$<?php echo e($product->price); ?></span>
                            <?php if($product->price>0): ?>
                              <?php 

                              $saving = ($product->sale_price*100)/ $product->price;
                              $saving = 100-(int)$saving;
                              ?>
                              <span class="saving">-<?php echo e($saving); ?>%</span> </p>
                            <?php endif; ?>
                        <?php else: ?>
                        <p class="price"> $<?php echo e($product->price); ?> </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="caption row attributes" >
                      <div class="col-md-6 " style="line-break:anywhere;text-align: left"><?php echo $product->color; ?></div>
                      <div class="col-md-6 " style="line-break:anywhere;text-align: right"><?php echo $product->size; ?></div>
                    </div>
                   
                    <div class="caption row attributes" >
                      <div class="col-md-6 " style="line-break:anywhere;text-align: left"><?php echo str_replace("|",",",$product->material); ?></div>
                      <div class="col-md-6 " style="line-break:anywhere;text-align: right"><?php echo str_replace("|",",",$product->fit_type); ?></div>
                    </div>

                    <div class="caption row attributes" >
                      <div class="col-md-6 " style="line-break:anywhere;text-align: left"><?php echo str_replace("|",",",$product->dress_length); ?></div>
                      <div class="col-md-6 " style="line-break:anywhere;text-align: right"><?php echo str_replace("|",",",$product->characters); ?></div>
                    </div>
                    <br/>
                 
                      <p><a href="<?php echo e($product->store_url); ?>"><?php echo e($product->store_name); ?></a></p>
                 
                       <div class="button-group">
                    
                     <div class="add-to-links">
                      <button type="button" data-toggle="tooltip" title="Set Product Alert" onClick=""><i class="fa fa-bell"></i></button>
                      <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
                      <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
                    </div>
                  </div>
                  </div>
                </div>
              </div>

                <?php 
                $i++;
                ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="row">
            <div class="col-sm-6 text-left">
                 <?php echo e($products && $products->total() >0 ? $products->withQueryString()->links('pagination::bootstrap-4') : ""); ?>

                </div>
             
                  <div class="col-sm-6 text-right">Showing <?php echo e(count($products->items())); ?> out of <?php echo e($products->total()); ?> items </div>
 
          </div>
          <?php else: ?>
          <h6>Products not found.</h6>
          <?php endif; ?>
          


        </div>
        <!--Middle Part End -->
      </div>
    </form>
    </div>
  </div>
   <div class="modal fade" id="mdoalallvalue" role="document">
       <form action="<?php echo e($_SERVER['PATH_INFO']); ?>" action="get" id="main_form"> 
      <div class="modal-dialog modal-lg">
        
          <!-- Modal content-->
          <div class="modal-content">
             
            <div class="modal-body" id="content-div">
              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary"  onClick="hideModal2()">Close</button>
              <button type="submit" class="btn btn-primary">Apply</button>
            </div>

          </div>

        </div>
    </form>

  </div>
  
   <script type="text/javascript">

     $('ul.term-list').each(function(){
      
      var LiN = $(this).find('li').length;
      
      if( LiN > 5){    
        $('li', this).eq(4).nextAll().hide().addClass('toggleable');
        $(this).append('<li class="more">Show More...</li>');    
      }
      
    });


    $('ul.term-list').on('click','.more', function(){
      
      if( $(this).hasClass('less') ){    
        $(this).text('Show More...').removeClass('less');    
      }else{
        $(this).text('Show Less...').addClass('less'); 
      }
      
      $(this).siblings('li.toggleable').slideToggle();
        
    }); 

     $('div.term-list').each(function(){
      
      var LiN = $(this).find('div').length;
      
      if( LiN > 5){    
        $('div', this).eq(4).nextAll().hide().addClass('toggleable');
        $(this).append('<div class="more">Show More...</div>');    
      }
      
    });


    $('div.term-list').on('click','.more', function(){
      
      if( $(this).hasClass('less') ){    
        $(this).text('Show More...').removeClass('less');    
      }else{
        $(this).text('Show Less...').addClass('less'); 
      }
      
      $(this).siblings('div.toggleable').slideToggle();
        
    }); 


    function  submitForm(filter="",value=""){

      if(filter == "price_range"){
        $("#min_price").val("");
        $("#max_price").val("");
      }

      if(filter == "price"){
        $("input[name=price_range]").prop("checked",false);
      }

       $("#main_form").submit();
    }
    function hideModal2(){

      $("#mdoalallvalue").modal('hide');
    }

     function loadTabData(){
    
        let _token   = $('meta[name="csrf-token"]').attr('content');

          $.ajax({
        url: "<?php echo e(route('create_filter_modal_content')); ?>",
        type:"GET",
        data:{
          _token: _token,  request_data:<?php echo json_encode($request_data); ?>
        },
        success:function(response){
         
          if(response && response !="") {
     
            $("#content-div").html(response);
            $("#mdoalallvalue").modal('show');
          }
        },
       });
     }


  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/products/stores_products.blade.php ENDPATH**/ ?>