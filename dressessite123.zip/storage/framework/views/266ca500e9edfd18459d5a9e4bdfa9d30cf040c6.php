

<?php $__env->startSection('content'); ?>

<div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <li><a href=""><?php echo e($selected->offer_type_name); ?></a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!--Left Part Start -->
        <aside id="column-left" class="col-sm-3 hidden-xs">
               <h5 >Categories</h5>
          <div class="box-category border_bottom" >
            <ul id="cat_accordion">
              <?php $__currentLoopData = $pc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <li><a href="/category_products/<?php echo e($cat->parent_category_slug); ?>"><?php echo e($cat->parent_category_name); ?></a> <span class="down"></span>
                <ul >
                 <?php if($cat->sub_parent_categories): ?>

                   <?php $__currentLoopData = $cat->sub_parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_parent_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   <li><a href="/category_products/<?php echo e($sub_parent_category->parent_category_slug); ?>">
                     <?php echo e($sub_parent_category->parent_category_name); ?>

                   </a>
                    <span class="down" ></span>
                    <ul >
                      <?php $__currentLoopData = $sub_parent_category->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/category_products/<?php echo e($sub_parent_category->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>"><?php echo e($category->category_name); ?></a> 
                          <?php if(!empty($category->sub_categories)): ?><span class="down"></span> <?php endif; ?>
                          <ul>
                            <?php if(isset($category->sub_categories)): ?>
                              <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/category_products/<?php echo e($sub_parent_category->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>/<?php echo e($sub_cat->category_slug); ?>"><?php echo e($sub_cat->category_name); ?> </a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </ul>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                   </li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <?php else: ?>
                   <?php $__currentLoopData = $cat->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><a href="/category_products/<?php echo e($cat->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>"><?php echo e($category->category_name); ?></a> 
                        <?php if(!empty($category->sub_categories)): ?><span class="down"></span> <?php endif; ?>
                        <ul>
                          <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><a href="/category_products/<?php echo e($cat->parent_category_slug); ?>/<?php echo e($category->category_slug); ?>/<?php echo e($sub_cat->category_slug); ?>"><?php echo e($sub_cat->category_name); ?> </a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>
                
                </ul>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </ul>
          </div>

          <h5 >Brand</h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $brands_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox"  id="checkboxSuccess" value="<?php echo e($brand->id); ?>">
                    <?php echo e($brand->store_name); ?> (<?php echo e(rand(1,300)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <h5 >Online Stores</h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $stores_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($store->id); ?>">
                    <?php echo e($store->store_name); ?> (<?php echo e(rand(1,300)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <h5>By Price </h5>
          <div class="side-item border_bottom">
            <div  class="form-inline row" style="margin-left: 1px">
              <div class="form-group   input-group col-md-5" >
                <label class="control-label input-group-addon" for="min_price">$</label>
                <input type="number" class="form-control" min="0" name="min_price" placeholder="Min" >
              </div>
              <span>-</span>
              <div class="form-group  input-group col-md-5"  >
                <label class="control-label input-group-addon" for="max_price">$</label>
                <input type="number" class="form-control" min="0" name="max_price" placeholder="Max" >
              </div>
            </div>
             <div class="container" style="padding-left: 2rem">
              <label class="radio">
                <input type="radio" class="radio" name="price_range" value="0-100"> <span>$0 - $100</span>
               </label>
                <label class="radio">
                  <input type="radio" class="radio" name="price_range" value="100-200"> <span>$100 - $200</span>
                </label>
                <label class="radio">
                  <input type="radio" class="radio" name="price_range" value="200-500" /> <span>$200 - $500</span>
                </label>
                <label class="radio">
                  <input type="radio" class="radio" name="price_range" value="500-1000"/> <span>$500 - $1000</span>
                </label>
                <label class="radio">
                  <input type="radio" class="radio" name="price_range" value="1000+"> <span>$1000+</span>
                </label>
            </div>
          </div>

          <h5>Dress Style  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $dress_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dstyle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($dstyle->id); ?>">
                    <?php echo e($dstyle->dress_style_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>

          </div>

           <h5>Length  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="border_bottom">

            <?php $__currentLoopData = $dress_lengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress_length): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($dress_length->id); ?>">
                    <?php echo e($dress_length->dress_length_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>

           <h5>Pattern  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $patterns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($pattern->id); ?>">
                    <?php echo e($pattern->pattern_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>

            <h5>Neckline  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $necklines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $neckline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($neckline->id); ?>">
                    <?php echo e($neckline->neckline_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>


            <h5>Sleeve Type  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $sleeve_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($sleeve_type->id); ?>">
                    <?php echo e($sleeve_type->sleeve_type_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>

          


            <h5>Embellishment  <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $embellishments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embellishment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($embellishment->id); ?>">
                    <?php echo e($embellishment->embellishment_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>

          

            <h5>Material  <a style="float:right;" href="#" data-loading-text="Loading..."  onclick="loadTabData()" ><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="<?php echo e($material->id); ?>">
                    <?php echo e($material->material_name); ?> (<?php echo e(rand(1,1000)); ?>) </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="checkbox">
                  <label>
                    <input type="checkbox" id="checkboxSuccess" value="">
                    Not Specified  (<?php echo e(rand(1,1000)); ?>)
                   </label>
                </div>
          </div>

           <h5>Colors </h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <button class="btn btn-circle" title ="<?php echo e($color->color_name); ?>" style="height: 30px; width: 30px;margin-bottom:3px;border:1px solid lightgray;border-radius: 100%;margin-right:2px;background:<?php echo e($color->color_code); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>
          <br/>
              <h5>Sizes <a style="float:right;"href="#" data-loading-text="Loading..."  onclick="loadTabData()"><small style="font-size:12px">View All</small></a></h5>
          <div class="side-item border_bottom">

            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <button class="btn btn-circle" title ="<?php echo e($color->color_name); ?>" style="margin-bottom:3px;border:1px solid lightgray;margin-right:2px;"><?php echo e($size->size_name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </div>


       
        </aside>
        <!--Left Part End -->
        <!--Middle Part Start-->
        <div id="content" class="col-sm-9">
          <h1 class="title"><?php echo e($selected->offer_type_name); ?></h1>
          <h3 class="subtitle">Other Offers</h3>
          <?php if($products ): ?>
          <div class="category-list-thumb row">

            <?php $__currentLoopData = $offer_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">  <a href="/offer_products/<?php echo e($offer['offer_type_slug']); ?>"><?php echo e($offer['offer_type_name']); ?>(<?php echo e(rand(1,10)); ?>)</a> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <div class="product-filter">
            <div class="row">
              <div class="col-md-4 col-sm-5">
                <div class="btn-group">
                  <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
                  <button type="button" id="grid-view" class="btn btn-default" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
                </div>
                <a href="compare.html" id="compare-total">Product Compare (0)</a> </div>
              <div class="col-sm-2 text-right">
                <label class="control-label" for="input-sort">Sort By:</label>
              </div>
              <div class="col-md-3 col-sm-2 text-right">
                <select id="input-sort" class="form-control col-sm-3">
                  <option value="" selected="selected">Default</option>
                  <option value="">Name (A - Z)</option>
                  <option value="">Name (Z - A)</option>
                  <option value="">Price (Low &gt; High)</option>
                  <option value="">Price (High &gt; Low)</option>
                  <option value="">Rating (Highest)</option>
                  <option value="">Rating (Lowest)</option>
                  <option value="">Model (A - Z)</option>
                  <option value="">Model (Z - A)</option>
                </select>
              </div>
              <div class="col-sm-1 text-right">
                <label class="control-label" for="input-limit">Show:</label>
              </div>
              <div class="col-sm-2 text-right">
                <select id="input-limit" class="form-control">
                  <option value="" selected="selected">20</option>
                  <option value="">25</option>
                  <option value="">50</option>
                  <option value="">75</option>
                  <option value="">100</option>
                </select>
              </div>
            </div>
          </div>
          <br />
          <div class="row products-category">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php 
             $product_image = "";

             if(strpos($product->image,',')!==false){
                $product_image = explode(",", $product->image)[0];
             }else{
                $product_image = $product->image;
             }
             ?>
            <div class="product-layout product-list col-xs-12">
              <div class="product-thumb">
                <div class="image"><a href="<?php echo e($product->product_url); ?>" target="blank"><img src="<?php echo e($product_image); ?>" alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" class="img-responsive" /></a></div>
                <div>
                  <div class="caption">
                    <h4><a href="<?php echo e($product->product_url); ?>" target="blank"> <?php echo e($product->name); ?></a></h4>
                    <p class="description"><?php echo e(substr($product->description,0,40)); ?>..</p>
                   
                    <?php if($product->sale_price && $product->sale_price !=""): ?>
                       <p class="price"> <span class="price-new">$<?php echo e($product->sale_price); ?></span> <span class="price-old">$<?php echo e($product->price); ?></span>
                        <?php if($product->price>0): ?>
                          <?php 

                          $saving = ($product->sale_price*100)/ $product->price;
                          $saving = 100-(int)$saving;
                          ?>
                          <span class="saving">-<?php echo e($saving); ?>%</span> </p>
                        <?php endif; ?>
                    <?php else: ?>
                    <p class="price"> $<?php echo e($product->price); ?> </p>
                    <?php endif; ?>
                    <?php if($product->size && $product->size !=""): ?>
                     <p> <b>Sizes:</b> <?php echo e(str_replace("|", ", ", $product->size)); ?> </p>
                    <?php endif; ?>

                    <?php if($product->color && $product->color !=""): ?>
                      <p> <b>Colors:</b> <?php echo e(str_replace("|", ", ", $product->color)); ?></p>
                    <?php endif; ?>

                    <?php if($product->material && $product->material !=""): ?>
                      <p> <b>Material:</b> <?php echo e(str_replace("|", ", ", $product->material)); ?></p>
                    <?php endif; ?>

                  </div>
                  <div class="button-group">
                    <button  class="btn-primary" type="button" onclick="window.open('<?php echo e($product->product_url); ?>','_blank')" ><span>View Product</span></button>
                    <div class="add-to-links">
                      <button type="button" data-toggle="tooltip" title="Add to wishlist" onClick=""><i class="fa fa-heart"></i></button>
                      <button type="button" data-toggle="tooltip" title="Add to compare" onClick=""><i class="fa fa-exchange"></i></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="row">
            <div class="col-sm-6 text-left">
      
            </div>
         
              <div class="col-sm-6 text-right"> </div>
 
          </div>
          <?php else: ?>
          <h6>Products not found.</h6>
          <?php endif; ?>
          


        </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>
   <div class="modal fade" id="mdoalallvalue" role="document">
      <div class="modal-dialog modal-lg">
      
        <!-- Modal content-->
        <div class="modal-content">
         
          <div class="modal-body">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#tab-brands">Brands</a></li>
              <li><a data-toggle="tab" href="#tab-online-stores">Online Stores</a></li>
              <li><a data-toggle="tab" href="#tab-colors">Color</a></li>
              <li><a data-toggle="tab" href="#tab-sizes">Size</a></li>
              <li><a data-toggle="tab" href="#tab-materials">Material</a></li>
              <li><a data-toggle="tab" href="#tab-pattern">Pattern</a></li>
              <li><a data-toggle="tab" href="#tab-dress-length">Dress Length</a></li>
              <li><a data-toggle="tab" href="#tab-sleeve-length">Sleeve Length</a></li>
              <li><a data-toggle="tab" href="#tab-sleeve-type">Sleeve Type</a></li>
              <li><a data-toggle="tab" href="#tab-fabric-type">Fabric Type</a></li>
              <li><a data-toggle="tab" href="#tab-feature">Feature</a></li>
              <li><a data-toggle="tab" href="#tab-fit-type">Fit Type</a></li>
              <li><a data-toggle="tab" href="#tab-garment-care">Garment Care</a></li>
              <li><a data-toggle="tab" href="#tab-neckline">Neckline</a></li>
              <li><a data-toggle="tab" href="#tab-occasion">Occasion</a></li>
              <li><a data-toggle="tab" href="#tab-season">Season</a></li>
              <li><a data-toggle="tab" href="#tab-specail-offers">Special Offers</a></li>
              <li><a data-toggle="tab" href="#tab-themes">Themes</a></li>
            </ul>
            <div class="tab-content" id="tab-content" >
              
              
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="hideModal()">Close</button>
            <button type="button" class="btn btn-primary">Apply</button>
          </div>

        </div>

      </div>

  </div>
  
  <script type="text/javascript">

    function hideModal(){
      $("#mdoalallvalue").modal('hide');
    }

     function loadTabData(){
    
        let _token   = $('meta[name="csrf-token"]').attr('content');

          $.ajax({
        url: "<?php echo e(route('create_filter_modal_content')); ?>",
        type:"GET",
        data:{
          _token: _token
        },
        success:function(response){
          
          if(response && response !="") {
            $("#tab-content").html(response);
            $("#mdoalallvalue").modal('show');
          }
        },
       });
     }


  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dressessite\resources\views/products/offer_products.blade.php ENDPATH**/ ?>