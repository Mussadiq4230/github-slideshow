<a href="#" onclick="hideModal3()" style="float: right;
    cursor: pointer;
    background-color: #efefef;
    color: #000;
    padding: 5px;
    border-radius: 25px;" >
              <i style="font-size: 21px;font-weight: normal;" class="fa fa-close"></i></a>
	<div class="row " style="padding:10px">

		<!--Middle Part Start-->
		<div id="content" class="col-sm-12">
			<div itemscope="" itemtype="http://schema.org/Product">
			
				<div class="row product-info">
					<div class="col-sm-6">
						<div class="image">
							<div style="height:425px;width:350px;" class="zoomWrapper">
								<img class="img-responsive" itemprop="image" id="zoom_01" src="<?php echo e($product->image); ?>" title="<?php echo e($product->name); ?>" alt="<?php echo e($product->name); ?>" data-zoom-image="<?php echo e($product->image); ?>" style="position: absolute; width: 350px; height: 425px;">
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
								<div style="background: url(&quot;image/progress.gif&quot;) center center no-repeat; height: 525px; width: 350px; z-index: 2000; position: absolute; display: none;"></div>
							</div>
						</div>

						<?php if(isset($product->all_images) && $product->all_images !=""): ?>

							<div class="center-block text-center">
								<span class="zoom-gallery"><i class="fa fa-search"></i> Click image for Gallery</span>
							</div>

							<?php 
							$images_array = explode('|',$product->all_images);

							?>

							<?php if(count($images_array)>1): ?>
							
								<div class="image-additional" id="gallery_01"> 

									<?php $__currentLoopData = $images_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<a class="thumbnail" href="#" data-zoom-image="<?php echo e($img); ?>" data-image="<?php echo e($img); ?>" title="<?php echo e($product->name); ?>">
											<img src="<?php echo e($img); ?>" title="<?php echo e($product->name); ?>" alt="<?php echo e($product->name); ?>">
										</a> 
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								</div>
							<?php endif; ?>

						<?php endif; ?>

					</div>
					<div class="col-sm-6">
						<br/>
						<br/>
						<h2 class="title" itemprop="name"><?php echo e($product->name); ?> </h2>
						<ul class="list-unstyled description">
							<li><b>Brand:</b> <a href="/redirect_to/<?php echo e($product->id); ?>"><span itemprop="brand"><?php echo e($product->store_name); ?></span></a></li>
							<li><b>Category:</b> <span itemprop="category"> <?php echo e($product->our_category ? $product->our_category->category_name : ""); ?> for  <?php echo e($product->parent_category ? $product->parent_category->parent_category_name: ""); ?></span></li>
							<li>
								<b>Color:</b> 
								<span itemprop="color">
									<?php echo e(str_replace('|',',',$product->color)); ?>

								</span>
							</li>
							<li>
								<b>Size:</b> 
								<span itemprop="size" class="badge badge-default" style="font-size:inherit">
									<?php echo e(str_replace('|',',',$product->size)); ?>

								</span>
							</li>
						</ul>
						<br/>
						<ul class="price-box" style="padding:15px">
							<?php 
							$from = "";

							if($product->price && $product->price !="" && $product->highest_price && $product->highest_price !=""){
								$from = "From ";
							}
							?>
							<li class="price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
								<span class="price-old"><?php echo e($product->currency); ?><?php echo e($product->price); ?>

								</span> 
								
								<span itemprop="price">	<?php echo e($product->currency); ?><?php echo e($product->sale_price); ?>

									<span itemprop="availability" content="In Stock"></span>
								</span>
							
							</li>

							<?php if($product->offer_type_id && $product->offer_type_id !=""): ?>
								<li>
									<br/>
									<span class="label label-success" style="padding:8px;border-radius:0px;font-size:16px"><?php echo e($product->offer_type); ?>

									</span>
									<?php if($product->discount_price && $product->discount_price): ?>
										<br/> Discount $<?php echo e($product->discount); ?>

									<?php endif; ?>
									
									<?php if($product->coupon_code && $product->coupon_code !=""): ?>
										
										<span style="margin-left:15px; background:white;border:2px dotted orange; border-radius: 0px; padding:8px;font-weight: bold;cursor: pointer" >
											<?php echo e($product->coupon_code); ?>

										</span>
										<small  title="Copy the Code" style="font-size:14px;cursor: pointer" onclick="copyToClipBoard('<?php echo e($product->coupon_code); ?>')">&nbsp;&nbsp;Copy</small>
										&nbsp;
										<span style="color:red;display: none;font-weight: bold" id="msg-copy" >Copied!</span>
									<?php endif; ?>

								</li>
							<?php endif; ?>
						</ul>
						<br/>


						<div id="product">
							
							<div class="cart">
								<div>
							
									<a href="/redirect_to/<?php echo e($product->id); ?>" target="blank" id="button-cart" class="btn btn-primary btn-lg">Buy this Product</a>
								</div>
								<div>
									<button type="button" class="wishlist" onclick=""><i class="fa fa-heart"></i> Add to Wish List</button>
									<br>
									<button type="button" class="wishlist" onclick=""><i class="fa fa-exchange"></i> Compare this Product</button>
								</div>
							</div>

							
							<table class="table table-bordered table-striped">
								<thead>
									<tr >
										<td colspan="2">
											<h4>Available Options</h4>
										</td>
									</tr>
								</thead>
								<tbody>
									
									<?php if($product->material && $product->material !=""): ?>
									<tr>
										<td><b>Material: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->material)); ?></td>
									</tr>
									<?php endif; ?>

									<?php if($product->feature && $product->feature !=""): ?>
									<tr>
										<td><b>Feature: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->feature)); ?></td>
									</tr>
									<?php endif; ?>
									
									<?php if($product->dress_length && $product->dress_length !=""): ?>
									<tr>
										<td><b>Dress Length: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->dress_length)); ?></td>
									</tr>
									<?php endif; ?>

									<?php if($product->character && $product->character !=""): ?>
									<tr>
										<td><b>Character: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->character)); ?></td>
									</tr>
									<?php endif; ?>

									<?php if($product->fit_type && $product->fit_type !=""): ?>
									<tr>
										<td><b>Fit Type: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->fit_type)); ?></td>
									</tr>
									<?php endif; ?>

									<?php if($product->closure && $product->closure !=""): ?>
									<tr>
										<td><b>Closure: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->closure)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->dress_style && $product->dress_style !=""): ?>
									<tr>
										<td><b>Dress Style: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->dress_style)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->pattern && $product->pattern !=""): ?>
									<tr>
										<td><b>Pattern: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->pattern)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->neckline && $product->neckline !=""): ?>
									<tr>
										<td><b>Neckline: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->neckline)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->theme && $product->theme !=""): ?>
									<tr>
										<td><b>Theme: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->theme)); ?></td>
									</tr>
									<?php endif; ?>	

								

									<?php if($product->fabric_type && $product->fabric_type !=""): ?>
									<tr>
										<td><b>Fabric Type: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->fabric_type)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->sleeve_length && $product->sleeve_length !=""): ?>
									<tr>
										<td><b>Sleeve Length: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->sleeve_length)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->sleeve_type && $product->sleeve_type !=""): ?>
									<tr>
										<td><b>Sleeve Type: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->sleeve_type)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->embellishment && $product->embellishment !=""): ?>
									<tr>
										<td><b>Embellishment: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->embellishment)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->occasion && $product->occasion !=""): ?>
									<tr>
										<td><b>Occasion: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->occasion)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->garment_care && $product->garment_care !=""): ?>
									<tr>
										<td><b>Garment Care: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->garment_care)); ?></td>
									</tr>
									<?php endif; ?>	

									<?php if($product->season && $product->season !=""): ?>
									<tr>
										<td><b>Season: </b> </td>
										<td><?php echo e(str_replace('|',',',$product->season)); ?></td>
									</tr>
									<?php endif; ?>	

								</tbody>
							</table>
						
								</p>
						

						</div>
						
						<hr>
						<!-- AddThis Button BEGIN -->
						<center>
					    <b>Share this:</b>
					      <br>
					      <a href="#" class="fa fa-facebook" onclick="share('facebook','<?php echo e(url($url)); ?>','<?php echo e($product->name); ?>');return false;" rel="nofollow" share_url="<?php echo e(url($url)); ?>" target="_blank"></a>
					      <a href="#" class="fa fa-twitter" onclick="share('twitter','<?php echo e(url($url)); ?>','<?php echo e($product->name); ?>')" rel="nofollow" share_url="<?php echo e(url($url)); ?>" target="_blank"></a>
					      <a href="#" class="fa fa-linkedin" onclick="share('linkedin', '<?php echo e(url($url)); ?>','<?php echo e($product->name); ?>')" rel="nofollow" share_url="<?php echo e($url); ?>">
					      
					      </a>
					       <a href="#" class="fa fa-tumblr" onclick="share('tumblr','<?php echo e(url($url)); ?>','<?php echo e($product->name); ?>')" rel="nofollow" share_url="<?php echo e($url); ?>">
					      
					      </a>
					      <a href="#" class="fa fa-mail" onclick="share('email','<?php echo e(url($url)); ?>','<?php echo e($product->name); ?>')" rel="nofollow" share_url="<?php echo e(url($url)); ?>">
					      @
					      </a>
					    </center>
						<!-- AddThis Button END -->
					</div>
				</div>
			</div>
		</div>
		<!--Middle Part End -->
	</div>
	<div class="row">
		<div class="col-md-12">
			<h4>Description:</h4>
			<p>
				<?php echo e($product->description); ?>

			</p>
		</div>
	</div>

	

<script type="text/javascript">

window.history.pushState("", "", "/<?php echo e($url); ?>");

function copyToClipBoard(code){

	navigator.clipboard.writeText(code);
	
	$("#msg-copy").show();
	
	setTimeout(function() {
		$("#msg-copy").hide();
	}, 20000);
}

$('#modal_product_details').on('hidden.bs.modal', function () {
  // 
  var url = $("#prev_url").val();
  window.history.pushState("", "", url);
})

</script><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/products/product_detail_content.blade.php ENDPATH**/ ?>