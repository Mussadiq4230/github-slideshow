<?php $__env->startSection('content'); ?>
<div id="container">
    <div class="container">
      <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-xs-12">
          <div class="row">
            <div class="col-sm-8">
              <!-- Slideshow Start-->
              <div class="slideshow single-slider owl-carousel">
                <div class="item"> <a href="#"><img class="img-responsive" src="<?php echo e(asset('image/banner-1-750x400.jpg')); ?>" alt="banner 1" /></a></div>
                <div class="item"> <a href="#"><img class="img-responsive" src="<?php echo e(asset('image/banner-2-750x400.jpg')); ?>" alt="banner 2" /></a></div>
                <div class="item"> <a href="#"><img class="img-responsive" src="<?php echo e(asset('image/banner-3-750x400.jpg')); ?>" alt="banner 3" /></a></div>
            </div>
            <!-- Slideshow End-->
        </div>
        <div class="col-sm-4 pull-right flip">
          <div class="marketshop-banner">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> <a href="#"><img title="sample-banner1" alt="sample-banner1" src="<?php echo e(asset('image/sp-small-banner-360x185.jpg')); ?>"></a></div>
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> <a href="#"><img title="sample-banner" alt="sample-banner" src="<?php echo e(asset('image/sp-small-banner1-360x185.jpg')); ?>"></a></div>
          </div>
      </div>
  </div>
</div>
<!-- Bestsellers Product Start-->
<h3 class="subtitle">Recommended For You</h3>
<div class="owl-carousel product_carousel">

   <?php $__currentLoopData = $for_you_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   <?php 
   $fy_product_image = "";

   if(strpos($product_fy->image,',')!==false){
      $fy_product_image = explode(",", $product_fy->image)[0];
   }else{
    $fy_product_image = $product_fy->image;
   }
   ?>
    <div class="product-thumb clearfix">
      <div class="image"><a href="product.html"><img src="<?php echo e($fy_product_image); ?>" alt="<?php echo e($product_fy->name); ?>" title="<?php echo e($product_fy->name); ?>" class="img-responsive" /></a></div>
      <div class="caption">
        <h4><a href="product.html"><?php echo e($product_fy->name); ?></a></h4>
        <?php if($product_fy->sale_price && $product_fy->sale_price !=""): ?>
           <p class="price"> <span class="price-new">$<?php echo e($product_fy->sale_price); ?></span> <span class="price-old">$<?php echo e($product_fy->price); ?></span>
            <?php if($product_fy->price>0): ?>
              <?php 

              $saving = ($product_fy->sale_price*100)/ $product_fy->price;
              $saving = 100-(int)$saving;
              ?>
              <span class="saving">-<?php echo e($saving); ?>%</span> </p>
            <?php endif; ?>
        <?php else: ?>
        <p class="price"> $<?php echo e($product_fy->price); ?> </p>
        <?php endif; ?>
        
        <?php if($product_fy->size && $product_fy->size !=""): ?>
         <p> <b>Sizes:</b> <?php echo e(str_replace("|", ", ", $product_fy->size)); ?> </p>
        <?php endif; ?>

        <?php if($product_fy->color && $product_fy->color !=""): ?>
          <p> <b>Colors:</b> <?php echo e(str_replace("|", ", ", $product_fy->color)); ?></p>
        <?php endif; ?>

        <?php if($product_fy->material && $product_fy->material !=""): ?>
          <p> <b>Material:</b> <?php echo e(str_replace("|", ", ", $product_fy->material)); ?></p>
        <?php endif; ?>

    </div>
    <div class="button-group">
        <button  class="btn-primary" type="button" onclick="window.open('<?php echo e($product_fy->product_url); ?>','_blank')" ><span>View Product</span></button>
        <div class="add-to-links">
          <button type="button" data-toggle="tooltip" title="Add to Wish List" onClick=""><i class="fa fa-heart"></i></button>
          <button type="button" data-toggle="tooltip" title="Compare this Product" onClick=""><i class="fa fa-exchange"></i></button>
      </div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!-- Featured Product End-->
<!-- Banner Start-->
<div class="marketshop-banner">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><a href="#"><img title="Sample Banner 2" alt="Sample Banner 2" src="<?php echo e(asset('image/sample-banner-3-360x360.jpg')); ?>"></a></div>
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><a href="#"><img title="Sample Banner" alt="Sample Banner" src="<?php echo e(asset('image/sample-banner-1-360x360.jpg')); ?>"></a></div>
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><a href="#"><img title="Sample Banner 3" alt="Sample Banner 3" src="<?php echo e(asset('image/sample-banner-2-360x360.jpg')); ?>"></a></div>
  </div>
</div>
<!-- Banner End-->
<?php 
$i=0;
?>
<?php $__currentLoopData = $products_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $i++; ?>
<!-- Categories Product Slider Start-->
<div class="category-module" id="latest_category<?php echo e($i); ?>">
    <h3 class="subtitle"><?php echo e($list->parent_category->parent_category_name); ?> - <a class="viewall" href="">view all</a></h3>
    <div class="category-module-content">
      <ul id="sub-cat" class="tabs">

        <?php $__currentLoopData = $list->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
        <li><a href="#tab-cat<?php echo e(str_replace(' ','_',$our_category->category_name).$our_category->id); ?>"><?php echo e($our_category->category_name); ?></a></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
     <?php $__currentLoopData = $list->our_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="tab-cat<?php echo e(str_replace(' ','_',$our_category->category_name).$our_category->id); ?>" class="tab_content">
      
        <div class="owl-carousel latest_category_tabs">
      
          <?php $__currentLoopData = $our_category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php 
             $product_image = "";

             if(strpos($product->image,',')!==false){
                $product_image = explode(",", $product->image)[0];
             }else{
              $product_image = $product->image;
             }
             ?>
          <div class="product-thumb">
            <div class="image"><a href="product.html"><img src="<?php echo e($product_image); ?>" alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" class="img-responsive" /></a></div>
            <div class="caption">
              <h4><a href="<?php echo e($product->product_url); ?>" target="blank" title="<?php echo e($product->name); ?>"><?php echo e($product->name); ?></a></h4>

             <?php if($product->sale_price && $product->sale_price !=""): ?>
               <p class="price"> <span class="price-new">$<?php echo e($product->sale_price); ?></span> <span class="price-old">$<?php echo e($product->price); ?></span>
                <?php if($product->price>0): ?>
                  <?php 

                  $saving = ($product->sale_price*100)/ $product->price;
                  $saving = 100-(int)$saving;
                  ?>
                  <span class="saving">-<?php echo e($saving); ?>%</span> </p>
                <?php endif; ?>
            <?php else: ?>
            <p class="price"> $<?php echo e($product->price); ?> </p>
            <?php endif; ?>
            
            <?php if($product->size && $product->size !=""): ?>
             <p> <b>Sizes:</b> <?php echo e(str_replace("|", ", ", $product->size)); ?> </p>
            <?php endif; ?>

            <?php if($product->color && $product->color !=""): ?>
              <p> <b>Colors:</b> <?php echo e(str_replace("|", ", ", $product->color)); ?></p>
            <?php endif; ?>

            <?php if($product->material && $product->material !=""): ?>
              <p> <b>Material:</b> <?php echo e(str_replace("|", ", ", $product->material)); ?></p>
            <?php endif; ?>

         
          </div>
          <div class="button-group">
               <button  class="btn-primary" type="button" onclick="window.open('<?php echo e($product_fy->product_url); ?>','_blank')" ><span>View Product</span></button>
              <div class="add-to-links">
                <button type="button" data-toggle="tooltip" title="Add to wishlist" onClick=""><i class="fa fa-heart"></i></button>
                <button type="button" data-toggle="tooltip" title="Add to compare" onClick=""><i class="fa fa-exchange"></i></button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Categories Product Slider End-->

<!-- Banner Start -->
<div class="marketshop-banner">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> <a href="#"><img title="1 Block Banner" alt="1 Block Banner" src="<?php echo e(asset('image/1blockbanner-1140x75.jpg')); ?>"></a></div>
  </div>
</div>
<!-- Banner End -->
<!-- Brand Logo Carousel Start-->
<div id="carousel" class="owl-carousel nxt">
    <?php $__currentLoopData = $top_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item text-center"> <a href="#"><img src="logos/<?php echo e($brand->store_logo); ?>" alt="<?php echo e($brand->store_name); ?>" class="img-responsive" width="145" /></a> </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</div>
<!-- Brand Logo Carousel End -->
</div>
<!--Middle Part End-->
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\trouserssite\resources\views/welcome.blade.php ENDPATH**/ ?>