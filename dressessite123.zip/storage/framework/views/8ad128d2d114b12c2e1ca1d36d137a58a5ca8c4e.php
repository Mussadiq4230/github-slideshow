

<?php $__env->startSection('content'); ?>

	<div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo e(route('online_stores')); ?>">Online Sores</a></li>
      </ul>
      <!-- Breadcrumb End-->

      <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-12">
        <h1 class="title">Find Your Favorite Online Store</h1>

            <p class="brand-index"><strong>Store Index:</strong>
                <?php $__currentLoopData = $online_stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#<?php echo e($key); ?>"><?php echo e($key); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
              
            <div class="manufacturer-info">

            <?php $__currentLoopData = $online_stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <h4 id="<?php echo e($key); ?>" class="manufacturer-title"><?php echo e($key); ?></h4>
              <div class="row">
              
                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-2 col-xs-6 manufacturer">
                    	<a href="/shop/<?php echo e($item->count_slug); ?>" class="thumbnail">
                            <img alt="<?php echo e($item->count_name); ?>" title="<?php echo e($item->count_name); ?>" src="logos/<?php echo e($item->image); ?>" width="120">
                        </a>
                        <a href="/shop/<?php echo e($item->count_slug); ?>"><?php echo e($item->count_name); ?> 
                          <?php if($item->total_count>0): ?>
                            (<?php echo e($item->total_count); ?>)
                          <?php endif; ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
            </div>
               
        </div>
        <!--Middle Part End -->
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\dressessite\resources\views/stores/online_stores.blade.php ENDPATH**/ ?>